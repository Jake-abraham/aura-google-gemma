import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { 
  Filter, 
  ChevronDown, 
  X, 
  Grid2X2, 
  Grid3X3, 
  Search,
  SlidersHorizontal,
  LayoutGrid,
  Heart,
  ShoppingBag,
  Eye,
  CheckCircle2
} from 'lucide-react';
import { PRODUCTS, type Product } from '../constants';
import { useShop } from '../context/ShopContext';
import { QuickViewModal } from './Home';

type SortOption = 'newest' | 'price-low' | 'price-high' | 'popular';

export default function Collections() {
  const { formatPrice, addToCart } = useShop();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [sortBy, setSortBy] = useState<SortOption>('newest');
  const [priceRange, setPriceRange] = useState<number>(100000);
  const [searchQuery, setSearchQuery] = useState('');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const [isSortOpen, setIsSortOpen] = useState(false);
  const [activeFilters, setActiveFilters] = useState<string[]>([]);

  const categories = ['All', 'Sarees', 'Kurtas', 'Festive Wear', 'Bridal'];

  const handleCategorySelect = (cat: string) => {
    setSelectedCategory(cat);
    if (cat !== 'All' && !activeFilters.includes(cat)) {
      setActiveFilters(prev => [...prev.filter(f => !categories.includes(f)), cat]);
    } else if (cat === 'All') {
      setActiveFilters(prev => prev.filter(f => !categories.includes(f)));
    }
  };

  const removeFilter = (filter: string) => {
    if (categories.includes(filter)) {
      setSelectedCategory('All');
    }
    setActiveFilters(prev => prev.filter(f => f !== filter));
  };

  const filteredProducts = useMemo(() => {
    let result = [...PRODUCTS];

    if (selectedCategory !== 'All') {
      result = result.filter(p => p.category === selectedCategory);
    }

    if (searchQuery) {
      result = result.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Price filtering (simplified for this demo)
    result = result.filter(p => p.priceINR ? p.priceINR <= priceRange : p.price * 83 <= priceRange);

    switch (sortBy) {
      case 'price-low':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'popular':
        // Mocking popularity by ID
        result.sort((a, b) => Number(b.id) - Number(a.id));
        break;
      default:
        result.sort((a, b) => Number(b.id) - Number(a.id));
    }

    return result;
  }, [selectedCategory, sortBy, priceRange, searchQuery]);

  return (
    <div className="pt-40 pb-20 px-6 max-w-7xl mx-auto min-h-screen">
      {/* Header */}
      <header className="mb-20 text-center relative">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           className="absolute -top-10 left-1/2 -translate-x-1/2 w-40 h-40 bg-brand-gold/5 rounded-full blur-3xl pointer-events-none"
        />
        <motion.span 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-brand-gold uppercase tracking-[0.8em] text-[10px] font-black mb-6 block"
        >
          Curated Heritage
        </motion.span>
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-6xl md:text-8xl font-serif text-brand-dark italic mb-8"
        >
          All Collections
        </motion.h1>
      </header>

      {/* Controls */}
      <div className="flex flex-col md:flex-row gap-8 items-center justify-between mb-12 sticky top-24 z-40 p-1 rounded-[3rem] bg-white/5 shadow-[0_8px_32px_rgba(0,0,0,0.15)] backdrop-blur-3xl border border-white/10 group">
        <div className="flex items-center gap-4 w-full md:w-auto p-4">
          <button 
            onClick={() => setIsFilterOpen(true)}
            className="flex items-center gap-4 px-10 py-5 rounded-full bg-brand-dark/95 text-white futuristic-glow border border-brand-gold/30 hover:border-brand-gold transition-all group"
          >
            <SlidersHorizontal size={18} className="text-brand-gold group-hover:rotate-180 transition-transform duration-500" />
            <span className="text-[10px] uppercase tracking-[0.3em] font-black">Refine Aura</span>
          </button>
        </div>

        <div className="flex items-center gap-6 w-full md:w-auto p-4">
          <div className="relative group/search flex-1 md:w-80">
            <Search className="absolute left-8 top-1/2 -translate-y-1/2 text-brand-gold/30 group-focus-within/search:text-brand-gold transition-colors" size={16} />
            <input 
              type="text" 
              placeholder="Seek an artifact..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-16 pr-8 py-5 rounded-full bg-white/10 border border-white/10 focus:border-brand-gold/40 focus:outline-none text-[10px] uppercase font-bold tracking-[0.2em] transition-all text-brand-dark placeholder:text-brand-dark/20 italic"
            />
          </div>

          <div className="relative">
            <button 
              onClick={() => setIsSortOpen(!isSortOpen)}
              className="flex items-center gap-6 px-10 py-5 rounded-full bg-white/30 backdrop-blur-xl border border-brand-gold/10 text-brand-dark text-[10px] uppercase tracking-[0.3em] font-black hover:bg-white hover:shadow-xl transition-all"
            >
              <div className="flex flex-col items-start gap-1">
                <span className="text-[8px] opacity-30 tracking-[0.5em] font-bold">Sort By</span>
                <span>{sortBy === 'newest' ? 'Ethereal Arrival' : sortBy === 'price-low' ? 'Modest to Grand' : sortBy === 'price-high' ? 'Grand to Modest' : 'Adored Most'}</span>
              </div>
              <ChevronDown size={14} className={`text-brand-gold transition-transform duration-500 ${isSortOpen ? 'rotate-180' : ''}`} />
            </button>

            <AnimatePresence>
              {isSortOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  className="absolute top-full right-0 mt-4 w-72 p-4 rounded-[2.5rem] bg-white shadow-[0_32px_64px_rgba(0,0,0,0.15)] border border-brand-gold/10 backdrop-blur-3xl z-50 overflow-hidden"
                >
                  <div className="absolute inset-0 bg-brand-gold/5" />
                  <div className="relative z-10 space-y-2">
                    {[
                      { id: 'newest', label: 'Ethereal Arrival' },
                      { id: 'price-low', label: 'Modest to Grand' },
                      { id: 'price-high', label: 'Grand to Modest' },
                      { id: 'popular', label: 'Adored Most' },
                    ].map((opt) => (
                      <button
                        key={opt.id}
                        onClick={() => {
                          setSortBy(opt.id as any);
                          setIsSortOpen(false);
                        }}
                        className={`w-full text-left px-8 py-5 rounded-2xl transition-all text-[10px] font-black uppercase tracking-[0.2em] relative group ${
                          sortBy === opt.id 
                            ? 'bg-brand-dark text-white shadow-xl' 
                            : 'hover:bg-brand-gold/10 text-brand-dark/60 hover:text-brand-dark'
                        }`}
                      >
                        {opt.label}
                        {sortBy === opt.id && <motion.div layoutId="sortActive" className="absolute left-4 top-1/2 -translate-y-1/2 w-1 h-4 bg-brand-gold rounded-full" />}
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Active Filters */}
      {activeFilters.length > 0 && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-wrap gap-4 mb-12 items-center"
        >
          <span className="text-[10px] uppercase font-black tracking-widest text-brand-dark/20 mr-4">Selected Essences:</span>
          {activeFilters.map(filter => (
            <button 
              key={filter}
              onClick={() => removeFilter(filter)}
              className="group flex items-center gap-3 px-6 py-3 rounded-full bg-brand-gold/5 border border-brand-gold/20 text-brand-gold text-[10px] font-black uppercase tracking-[0.2em] hover:bg-brand-gold hover:text-white transition-all shadow-sm"
            >
              {filter}
              <X size={12} className="group-hover:rotate-90 transition-transform" />
            </button>
          ))}
          <button 
            onClick={() => {
              setSelectedCategory('All');
              setActiveFilters([]);
            }}
            className="text-[10px] uppercase font-black tracking-[0.35em] text-brand-rose hover:text-brand-rose/60 transition-colors ml-4 border-b border-brand-rose/20 pb-1"
          >
            Purify All
          </button>
        </motion.div>
      )}

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-12">
        <AnimatePresence mode="popLayout">
          {filteredProducts.map((product, idx) => (
            <CollectionCard 
              key={product.id} 
              product={product} 
              index={idx}
              onQuickView={() => setSelectedProduct(product)}
            />
          ))}
        </AnimatePresence>
      </div>

      {filteredProducts.length === 0 && (
        <div className="py-40 text-center">
          <div className="w-20 h-20 bg-brand-cream rounded-full flex items-center justify-center mx-auto mb-8 text-brand-gold/30">
            <Search size={40} />
          </div>
          <h3 className="text-2xl font-serif italic text-brand-dark">No artifacts found</h3>
          <p className="text-brand-dark/40 text-[10px] uppercase tracking-widest font-bold mt-2">Try adjusting your ethereal filters</p>
        </div>
      )}

      {/* Advanced Filter Modal */}
      <AnimatePresence>
        {isFilterOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsFilterOpen(false)}
              className="fixed inset-0 bg-brand-dark/40 backdrop-blur-md z-[100]"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 w-full max-w-md h-full bg-white z-[110] shadow-2xl p-12 overflow-y-auto"
            >
              <div className="flex justify-between items-center mb-16">
                <h2 className="text-4xl font-serif italic text-brand-dark">Studio Filter</h2>
                <button onClick={() => setIsFilterOpen(false)} className="p-4 bg-brand-cream rounded-full hover:rotate-90 transition-transform duration-500">
                  <X size={24} />
                </button>
              </div>

              <div className="space-y-12">
                <div>
                  <h4 className="text-[10px] uppercase tracking-widest font-black text-brand-gold mb-6">Aura Category</h4>
                  <div className="flex flex-wrap gap-3">
                    {categories.map((cat) => (
                      <button
                        key={cat}
                        onClick={() => handleCategorySelect(cat)}
                        className={`px-6 py-3 rounded-full text-[10px] uppercase tracking-widest font-black transition-all ${
                          selectedCategory === cat 
                            ? 'bg-brand-dark text-white shadow-xl' 
                            : 'bg-brand-cream text-brand-dark/40 hover:text-brand-dark border border-brand-gold/10'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-[10px] uppercase tracking-widest font-black text-brand-gold mb-6">Price Ceiling</h4>
                  <input 
                    type="range" 
                    min="5000" 
                    max="200000" 
                    step="5000"
                    value={priceRange}
                    onChange={(e) => setPriceRange(Number(e.target.value))}
                    className="w-full accent-brand-gold cursor-pointer"
                  />
                  <div className="flex justify-between mt-4">
                    <span className="text-[10px] font-bold text-brand-dark/40">₹5,000</span>
                    <span className="text-sm font-serif italic font-bold">Up to ₹{priceRange.toLocaleString()}</span>
                  </div>
                </div>

                <div>
                  <h4 className="text-[10px] uppercase tracking-widest font-black text-brand-gold mb-6">Aura Palette (Colors)</h4>
                  <div className="flex flex-wrap gap-4">
                    {['Royal Gold', 'Crimson', 'Emerald', 'Ivory', 'Midnight'].map((color) => (
                      <button key={color} className="flex flex-col items-center gap-2 group">
                        <div className={`w-10 h-10 rounded-full border border-brand-gold/20 flex items-center justify-center p-1 group-hover:scale-110 transition-transform`}>
                          <div className={`w-full h-full rounded-full ${color === 'Royal Gold' ? 'bg-[#C89B3C]' : color === 'Crimson' ? 'bg-[#991B1B]' : color === 'Emerald' ? 'bg-[#065F46]' : color === 'Ivory' ? 'bg-[#F9F7F2]' : 'bg-[#111827]'}`} />
                        </div>
                        <span className="text-[8px] uppercase tracking-widest font-bold opacity-40 group-hover:opacity-100">{color}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-[10px] uppercase tracking-widest font-black text-brand-gold mb-6">Sizing Spectrum</h4>
                  <div className="flex gap-4">
                    {['S', 'M', 'L', 'XL'].map((size) => (
                      <button key={size} className="w-12 h-12 rounded-2xl border border-brand-gold/10 flex items-center justify-center text-[10px] font-black hover:border-brand-gold hover:text-brand-gold transition-all">
                        {size}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-[10px] uppercase tracking-widest font-black text-brand-gold mb-6">Celestial Order</h4>
                  <div className="grid grid-cols-1 gap-4">
                    {[
                      { id: 'newest', label: 'Ethereal Arrival' },
                      { id: 'price-low', label: 'Modest to Grand' },
                      { id: 'price-high', label: 'Grand to Modest' },
                      { id: 'popular', label: 'Adored Most' },
                    ].map((opt) => (
                      <button
                        key={opt.id}
                        onClick={() => setSortBy(opt.id as any)}
                        className={`w-full text-left px-8 py-5 rounded-2xl border transition-all text-xs font-bold uppercase tracking-widest ${
                          sortBy === opt.id 
                            ? 'border-brand-gold bg-brand-gold/5 text-brand-gold' 
                            : 'border-brand-gold/10 hover:border-brand-gold'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <button 
                onClick={() => setIsFilterOpen(false)}
                className="w-full mt-20 gold-shimmer text-white py-6 rounded-full text-[10px] uppercase tracking-widest font-black shadow-2xl"
              >
                Apply Curation
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <QuickViewModal 
        product={selectedProduct!} 
        isOpen={!!selectedProduct} 
        onClose={() => setSelectedProduct(null)} 
      />
    </div>
  );
}

const CollectionCard = ({ product, index, onQuickView }: { product: Product; index: number; onQuickView: () => void; key?: React.Key }) => {
  const navigate = useNavigate();
  const { addToCart, formatPrice } = useShop();
  const [isHovered, setIsHovered] = useState(false);
  const [justAdded, setJustAdded] = useState(false);

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 2000);
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ delay: (index % 4) * 0.1 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group relative cursor-pointer"
      onClick={() => navigate(`/product/${product.id}`)}
    >
      <div className="aspect-[3/4] rounded-[3rem] overflow-hidden bg-white mb-8 relative shadow-2xl futuristic-glow group-hover:border-brand-gold/40 border border-transparent transition-all duration-700">
        <AnimatePresence mode="wait">
          <motion.img 
            key={isHovered ? 'hover' : 'default'}
            src={isHovered && product.image2 ? product.image2 : product.image} 
            alt={product.name}
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: isHovered ? 1.15 : 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1, ease: [0.19, 1, 0.22, 1] }}
            className="w-full h-full object-cover" 
          />
        </AnimatePresence>
        
        <div className={`absolute inset-0 bg-brand-dark/20 backdrop-blur-[4px] transition-all duration-700 flex flex-col items-center justify-center gap-6 ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
          <div className="flex gap-4 transform translate-y-8 group-hover:translate-y-0 transition-transform duration-700">
            <motion.button 
              whileHover={{ scale: 1.1, backgroundColor: '#C89B3C', color: '#fff' }}
              whileTap={{ scale: 0.9 }}
              onClick={(e) => { e.stopPropagation(); onQuickView(); }}
              className="w-16 h-16 bg-white/95 rounded-full flex items-center justify-center text-brand-dark shadow-[0_10px_30px_rgba(0,0,0,0.3)] transition-all"
            >
              <Search size={22} />
            </motion.button>
            <motion.button 
              whileHover={{ scale: 1.1, backgroundColor: '#C89B3C', color: '#fff' }}
              whileTap={{ scale: 0.9 }}
              onClick={handleAdd}
              className={`w-16 h-16 bg-white/95 rounded-full flex items-center justify-center text-brand-dark shadow-[0_10px_30px_rgba(0,0,0,0.3)] transition-all ${justAdded ? 'bg-brand-green text-white scale-110 shadow-[0_0_20px_rgba(58,157,93,0.5)]' : ''}`}
            >
              {justAdded ? <CheckCircle2 size={22} /> : <ShoppingBag size={22} />}
            </motion.button>
          </div>
          <motion.span className="text-[10px] uppercase tracking-[0.4em] font-black text-white transform translate-y-8 group-hover:translate-y-0 transition-transform duration-700 delay-100">
            Quick Inquire
          </motion.span>
        </div>

        <button 
          onClick={(e) => { e.stopPropagation(); }}
          className="absolute top-8 right-8 p-4 bg-white/90 backdrop-blur-xl rounded-full text-brand-dark hover:text-brand-rose hover:scale-125 transition-all shadow-2xl opacity-0 group-hover:opacity-100 translate-x-10 group-hover:translate-x-0 duration-700"
        >
          <Heart size={18} />
        </button>

        <div className="absolute bottom-8 left-10">
          <div className="w-1 h-8 bg-brand-gold/50 rounded-full group-hover:h-12 group-hover:bg-brand-gold transition-all duration-700" />
        </div>
      </div>

      <div className="text-center px-4">
        <span className="text-[10px] uppercase tracking-[0.6em] font-black text-brand-gold mb-4 block opacity-40 group-hover:opacity-100 transition-all">
          {product.category}
        </span>
        <h3 className="text-3xl font-serif italic text-brand-dark mb-4 group-hover:text-brand-gold group-hover:translate-y-[-4px] transition-all duration-700">
          {product.name}
        </h3>
        <div className="flex items-center justify-center gap-6">
          <div className="h-px w-0 group-hover:w-12 bg-brand-gold/30 transition-all duration-700" />
          <p className="text-brand-dark font-black tracking-widest text-sm flex items-center gap-4">
            <span className="opacity-20 line-through text-[10px]">{formatPrice(product.price * 1.3, product)}</span>
            <span className="text-brand-dark group-hover:scale-110 transition-transform inline-block">{formatPrice(product.price, product)}</span>
          </p>
          <div className="h-px w-0 group-hover:w-12 bg-brand-gold/30 transition-all duration-700" />
        </div>
      </div>
    </motion.div>
  );
};
