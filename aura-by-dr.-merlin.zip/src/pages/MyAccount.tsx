import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Package, 
  MapPin, 
  User, 
  ChevronRight, 
  ShoppingBag,
  CreditCard,
  LogOut,
  Clock,
  CheckCircle2,
  Settings,
  Heart,
  ArrowRight,
  Trash2,
  ShieldCheck,
  Globe
} from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { collection, query, where, getDocs, orderBy, doc, getDoc } from 'firebase/firestore';
import { onAuthStateChanged, signOut, updateProfile } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';
import { useShop } from '../context/ShopContext';

export default function MyAccount() {
  const [user, setUser] = useState(auth.currentUser);
  const [userData, setUserData] = useState<any>(null);
  const [orders, setOrders] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'orders' | 'addresses' | 'details' | 'settings'>('orders');
  const [loading, setLoading] = useState(true);
  const { formatPrice } = useShop();
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      if (u) {
        setUser(u);
        try {
          const d = await getDoc(doc(db, 'users', u.uid));
          setUserData(d.data());
          fetchOrders(u.uid);
        } catch (error) {
          console.error("Fetch Data Error:", error);
        }
      } else {
        navigate('/auth');
      }
      setLoading(false);
    });
    return unsubscribe;
  }, [navigate]);

  const fetchOrders = async (userId: string) => {
    try {
      const q = query(
        collection(db, 'orders'), 
        where('userId', '==', userId),
        orderBy('createdAt', 'desc')
      );
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setOrders(data);
    } catch (error) {
      console.error("Fetch Orders Error:", error);
    }
  };

  const handleSignOut = async () => {
    await signOut(auth);
    navigate('/');
  };

  if (loading) return (
    <div className="h-screen flex items-center justify-center bg-mesh">
      <div className="relative">
        <motion.div 
          animate={{ rotate: 360, scale: [1, 1.2, 1] }} 
          transition={{ repeat: Infinity, duration: 2, ease: 'linear' }}
          className="w-32 h-32 border-t-2 border-brand-gold rounded-full shadow-[0_0_50px_#C89B3C]" 
        />
        <div className="absolute inset-0 flex items-center justify-center text-[10px] uppercase tracking-[0.5em] font-black text-brand-gold animate-pulse">Aura</div>
      </div>
    </div>
  );

  const tabs = [
    { id: 'orders', icon: Package, label: 'Ledger History', count: orders.length },
    { id: 'addresses', icon: MapPin, label: 'Aura Havens', count: userData?.savedAddresses?.length || 0 },
    { id: 'details', icon: User, label: 'Ethereal Profile' },
    { id: 'settings', icon: Settings, label: 'Studio Tuning' },
  ];

  return (
    <div className="min-h-screen bg-mesh pt-48 pb-32 px-6 selection:bg-brand-gold selection:text-white">
      {/* Background Ambience */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-brand-gold/5 rounded-full blur-[150px] -mr-96 -mt-96" />
        <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-brand-dark/5 rounded-full blur-[150px] -ml-64 -mb-64" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <header className="mb-24 flex flex-col md:flex-row md:items-end justify-between gap-12 border-b border-brand-gold/10 pb-16">
          <div className="flex items-center gap-10">
            <motion.div 
              initial={{ scale: 0.8, opacity: 0, rotate: -20 }}
              animate={{ scale: 1, opacity: 1, rotate: 0 }}
              className="w-40 h-40 rounded-[3rem] bg-brand-dark text-brand-gold flex items-center justify-center font-serif text-6xl shadow-[0_30px_60px_rgba(0,0,0,0.5)] border border-brand-gold/20 relative group overflow-hidden futuristic-glow"
            >
              <div className="absolute inset-0 bg-mesh opacity-20" />
              <span className="relative z-10 italic shimmer-text">{userData?.name?.charAt(0) || user?.email?.charAt(0).toUpperCase()}</span>
            </motion.div>
            <div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-4 mb-4"
              >
                <span className="h-px w-10 bg-brand-gold" />
                <span className="text-brand-gold text-[10px] uppercase tracking-[0.6em] font-black italic">Imperial Resident</span>
              </motion.div>
              <motion.h1 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="text-6xl md:text-8xl font-serif italic text-brand-dark mb-6 tracking-tighter drop-shadow-sm"
              >
                Salutations, {userData?.name?.split(' ')[0] || 'Seeker'}
              </motion.h1>
              <div className="flex flex-wrap items-center gap-6">
                <div className="px-6 py-2 bg-brand-dark text-brand-gold text-[10px] uppercase font-black tracking-[0.4em] rounded-full futuristic-glow">
                  Rank: Master Weaver
                </div>
                <span className="text-[10px] uppercase font-black tracking-[0.3em] text-brand-dark/20 italic">
                  Chamber established {userData?.createdAt ? new Date(userData.createdAt).getFullYear() : 2024}
                </span>
              </div>
            </div>
          </div>
          <motion.button 
            whileHover={{ scale: 1.05, backgroundColor: 'rgba(180, 50, 50, 0.1)' }}
            onClick={handleSignOut}
            className="flex items-center gap-4 text-[10px] uppercase tracking-[0.5em] font-black text-brand-rose/60 hover:text-brand-rose transition-all px-10 py-6 rounded-full border border-brand-rose/10 bg-white/5 backdrop-blur-xl"
          >
            <LogOut size={18} /> Sever Connection
          </motion.button>
        </header>

        <div className="flex flex-col lg:flex-row gap-20">
          {/* Navigation - Glassmorphism Sidebar */}
          <aside className="lg:w-96">
            <nav className="space-y-4">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`w-full flex items-center justify-between px-12 py-7 rounded-[2.5rem] text-[10px] uppercase tracking-[0.4em] font-black transition-all relative group overflow-hidden ${
                    activeTab === tab.id 
                      ? 'bg-brand-dark text-white shadow-2xl futuristic-glow' 
                      : 'bg-white/5 backdrop-blur-3xl border border-white/20 text-brand-dark/30 hover:text-brand-dark hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center gap-6 relative z-10 transition-transform group-hover:translate-x-2">
                    <tab.icon size={20} className={activeTab === tab.id ? 'text-brand-gold' : ''} />
                    {tab.label}
                  </div>
                  {tab.count !== undefined && (
                    <span className={`relative z-10 px-4 py-1.5 rounded-full text-[9px] font-black shadow-inner ${
                      activeTab === tab.id ? 'bg-brand-gold text-brand-dark' : 'bg-brand-dark/5 text-brand-gold'
                    }`}>
                      {tab.count}
                    </span>
                  )}
                  {activeTab === tab.id && (
                    <motion.div 
                      layoutId="navGlow" 
                      className="absolute inset-0 bg-brand-dark z-0" 
                    />
                  )}
                </button>
              ))}
            </nav>

            <div className="mt-20 p-10 bg-white/5 backdrop-blur-3xl rounded-[3rem] border border-white/20 relative overflow-hidden group shadow-2xl">
              <div className="absolute inset-0 bg-mesh opacity-10" />
              <div className="relative z-10">
                <h4 className="text-xl font-serif italic mb-4 text-brand-dark">Aura Concierge</h4>
                <p className="text-[10px] uppercase tracking-widest leading-relaxed text-brand-dark/40 font-bold mb-8">Need bespoke adjustments? Our artisans are ready.</p>
                <button className="text-[10px] uppercase tracking-[0.4em] font-black text-brand-gold group-hover:tracking-[0.6em] transition-all flex items-center gap-3">
                  Consult Now <ArrowRight size={14} />
                </button>
              </div>
            </div>
          </aside>

          {/* Content Area */}
          <main className="flex-1">
            <AnimatePresence mode="wait">
              {activeTab === 'orders' && (
                <motion.div 
                  key="orders"
                  initial={{ opacity: 0, x: 30 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -30 }}
                  transition={{ duration: 0.6 }}
                  className="space-y-12"
                >
                  {orders.length > 0 ? (
                    <div className="grid gap-10">
                      {orders.map((order) => (
                        <div key={order.id} className="bg-white/5 backdrop-blur-3xl rounded-[4rem] shadow-2xl border border-white/20 overflow-hidden group hover:border-brand-gold/30 transition-all futuristic-glow">
                          <div className="p-12 flex flex-col md:flex-row md:items-center justify-between gap-10">
                            <div className="flex items-center gap-10">
                              <div className="w-24 h-24 bg-brand-dark text-brand-gold rounded-[2.5rem] flex items-center justify-center shadow-2xl group-hover:rotate-12 transition-all futuristic-glow">
                                <ShoppingBag size={32} />
                              </div>
                              <div>
                                <div className="flex items-center gap-4 mb-3">
                                  <h3 className="text-[12px] uppercase tracking-[0.4em] font-black text-brand-dark">Ledger ID: #{order.id?.slice(-8).toUpperCase()}</h3>
                                  <span className={`px-6 py-1.5 rounded-full text-[9px] uppercase font-black tracking-[0.3em] shadow-lg ${
                                    order.status === 'processing' ? 'bg-brand-gold/10 text-brand-gold' : 'bg-brand-green/10 text-brand-green'
                                  }`}>
                                    {order.status}
                                  </span>
                                </div>
                                <p className="text-[10px] font-black uppercase tracking-[0.4em] text-brand-dark/30 italic">Materialized on {new Date(order.createdAt?.seconds * 1000).toLocaleDateString()}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-12">
                              <div className="text-right">
                                <p className="text-[10px] uppercase tracking-[0.5em] text-brand-gold font-black mb-2 italic">Aura Value</p>
                                <p className="text-4xl font-serif text-brand-dark italic tracking-tighter">{formatPrice(order.total)}</p>
                              </div>
                              <button className="bg-brand-dark p-6 rounded-full text-brand-gold hover:scale-110 transition-all shadow-2xl futuristic-glow group/btn">
                                <ChevronRight size={28} className="group-hover/btn:translate-x-1" />
                              </button>
                            </div>
                          </div>
                          {/* Visual Items Preview */}
                          <div className="bg-white/5 px-12 py-8 border-t border-white/10 flex gap-6 overflow-x-auto scrollbar-hide items-center">
                            {order.items?.map((item: any, idx: number) => (
                              <div key={idx} className="relative group/item">
                                <img src={item.image} alt="" className="w-20 h-28 object-cover rounded-2xl shadow-xl grayscale-[0.8] group-hover/item:grayscale-0 transition-all duration-700 hover:scale-105" />
                                <div className="absolute inset-0 bg-brand-gold/20 opacity-0 group-hover/item:opacity-100 transition-opacity rounded-2xl" />
                              </div>
                            ))}
                            <div className="flex-1" />
                            <div className="flex items-center gap-3">
                              <CheckCircle2 size={16} className="text-brand-gold" />
                              <span className="text-[10px] uppercase tracking-widest font-black text-brand-dark/30">Verified Acquisition</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <motion.div 
                      className="bg-white/5 backdrop-blur-3xl rounded-[5rem] border border-white/20 p-24 text-center flex flex-col items-center gap-10 shadow-2xl futuristic-glow mt-10"
                    >
                      <div className="w-32 h-32 bg-white/5 rounded-full flex items-center justify-center text-brand-gold/20 shadow-inner">
                        <ShoppingBag size={56} strokeWidth={1} className="animate-pulse" />
                      </div>
                      <div className="max-w-md">
                        <h3 className="text-4xl font-serif mb-6 italic tracking-tight">The Imperial Vault is Empty</h3>
                        <p className="text-xs text-brand-dark/30 italic leading-relaxed tracking-widest font-medium">Your exploration through Aura creations hasn't yet recorded any divine acquisitions. The stars wait for your choice.</p>
                      </div>
                      <motion.button 
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => navigate('/collections')}
                        className="gold-shimmer text-white px-16 py-7 rounded-full text-[10px] uppercase tracking-[0.5em] font-black shadow-2xl transition-all futuristic-glow"
                      >
                        Begin Your Chronicle
                      </motion.button>
                    </motion.div>
                  )}
                </motion.div>
              )}

              {activeTab === 'addresses' && (
                <motion.div 
                  key="addresses"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-16"
                >
                  <header className="flex justify-between items-end mb-12">
                    <div>
                      <h3 className="text-5xl font-serif italic text-brand-dark">Reach Havens</h3>
                      <p className="text-[10px] uppercase tracking-[0.4em] text-brand-dark/30 font-black mt-3">Locations mapped for Imperial Courier delivery</p>
                    </div>
                    <button className="px-10 py-5 rounded-full bg-brand-dark text-brand-gold text-[10px] uppercase tracking-widest font-black shadow-2xl hover:bg-brand-gold hover:text-white transition-all futuristic-glow">+ Access New Haven</button>
                  </header>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    {userData?.savedAddresses?.map((addr: any, i: number) => (
                      <motion.div 
                        key={i} 
                        whileHover={{ y: -10 }}
                        className="bg-white/5 backdrop-blur-3xl p-12 rounded-[4rem] shadow-2xl border border-white/20 relative group overflow-hidden"
                      >
                        <div className="absolute inset-0 bg-mesh opacity-10 pointer-events-none" />
                        <MapPin className="text-brand-gold mb-8 shadow-[0_0_20px_#C89B3C]" size={32} />
                        <p className="text-2xl font-serif italic text-brand-dark mb-6 leading-relaxed">{addr.street}, {addr.city}</p>
                        <div className="flex items-center justify-between">
                          <p className="text-[10px] uppercase tracking-[0.4em] text-brand-dark/30 font-black">Spatial Index: {addr.zip} &bull; {addr.country}</p>
                          <button className="text-brand-rose opacity-0 group-hover:opacity-100 transition-opacity hover:rotate-12 transform-gpu">
                            <Trash2 size={20} />
                          </button>
                        </div>
                      </motion.div>
                    ))}
                    <div className="bg-white/5 backdrop-blur-sm p-12 rounded-[4rem] border-2 border-dashed border-brand-gold/10 flex flex-col items-center justify-center text-center opacity-30 group hover:opacity-100 transition-opacity cursor-pointer">
                      <motion.div 
                        animate={{ y: [0, -10, 0] }}
                        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                      >
                        <MapPin className="text-brand-gold/30 mb-6 group-hover:text-brand-gold transition-colors" size={48} />
                      </motion.div>
                      <p className="text-[10px] uppercase tracking-[0.5em] font-black">Undiscovered Haven</p>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'details' && (
                <motion.div 
                  key="details"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 1.05 }}
                  className="space-y-20 max-w-4xl"
                >
                  <div>
                    <h3 className="text-5xl font-serif italic text-brand-dark mb-4">Vessel Attributes</h3>
                    <p className="text-[10px] uppercase tracking-[0.4em] text-brand-dark/30 font-black">Your unique identity in the Aura Matrix</p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                    <div className="space-y-6">
                      <label className="block text-[10px] uppercase tracking-[0.5em] text-brand-gold font-black ml-6 italic">Secure Cipher (Email)</label>
                      <div className="w-full px-10 py-7 rounded-[3rem] bg-white/5 backdrop-blur-xl text-lg font-serif italic text-brand-dark/40 border border-white/20 flex items-center justify-between shadow-inner">
                        {user?.email}
                        <ShieldCheck size={20} className="text-brand-gold/30" />
                      </div>
                    </div>
                    <div className="space-y-6 group">
                      <label className="block text-[10px] uppercase tracking-[0.5em] text-brand-gold font-black ml-6 transition-all group-focus-within:tracking-[0.7em] italic">Artisan Signature (Full Name)</label>
                      <input 
                        type="text" 
                        defaultValue={userData?.name}
                        className="w-full px-12 py-7 rounded-[3rem] bg-white/5 backdrop-blur-xl border border-white/20 focus:border-brand-gold focus:outline-none text-xl font-serif italic text-brand-dark shadow-2xl transition-all placeholder:text-brand-dark/10" 
                        placeholder="Define your name..."
                      />
                    </div>
                    <div className="md:col-span-2 pt-10">
                      <motion.button 
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        className="gold-shimmer text-white px-20 py-8 rounded-full text-[12px] uppercase tracking-[0.6em] font-black shadow-[0_30px_60px_rgba(200,155,60,0.3)] transition-all flex items-center justify-center gap-6 futuristic-glow"
                      >
                        Commit to Chronicle <CheckCircle2 size={24} />
                      </motion.button>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'settings' && (
                <motion.div
                  key="settings"
                  initial={{ opacity: 0, rotateX: 10 }}
                  animate={{ opacity: 1, rotateX: 0 }}
                  className="space-y-16"
                >
                  <div className="flex items-center gap-6">
                     <h3 className="text-5xl font-serif italic text-brand-dark">Studio Dynamics</h3>
                     <div className="h-px flex-1 bg-brand-gold/10" />
                  </div>
                  <div className="bg-white/5 backdrop-blur-3xl rounded-[5rem] border border-white/20 p-16 space-y-10 shadow-2xl futuristic-glow">
                    {[
                      { icon: Globe, label: 'Celestial Alerts', desc: 'Sync when artifacts are dispatched from the studio', status: true },
                      { icon: Heart, label: 'Wishlist Broadcast', desc: 'Allow artisans to prioritize your curated dreams', status: false },
                      { icon: CreditCard, label: 'Flow Optimization', desc: 'Retain secure links to your credit vessels', status: true }
                    ].map((pref, i) => (
                      <motion.div 
                        key={i} 
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.1 }}
                        className="flex items-center justify-between py-10 border-b border-brand-gold/10 last:border-0 group"
                      >
                        <div className="flex items-center gap-10">
                          <div className="w-16 h-16 rounded-[2rem] bg-brand-dark text-brand-gold flex items-center justify-center shadow-2xl group-hover:rotate-12 transition-all">
                            <pref.icon size={24} />
                          </div>
                          <div>
                            <p className="text-2xl font-serif italic text-brand-dark mb-2 tracking-tight transition-colors group-hover:text-brand-gold">{pref.label}</p>
                            <p className="text-[10px] uppercase tracking-[0.4em] text-brand-dark/30 font-black italic">{pref.desc}</p>
                          </div>
                        </div>
                        <button className={`w-20 h-10 rounded-full p-1.5 transition-all relative ${pref.status ? 'bg-brand-gold shadow-[0_0_20px_#C89B3C]' : 'bg-brand-dark/10'}`}>
                          <motion.div 
                            animate={{ x: pref.status ? 40 : 0 }}
                            className={`w-7 h-7 bg-white rounded-full shadow-2xl transition-all ${pref.status ? 'bg-white' : 'bg-white/50'}`} 
                          />
                        </button>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </main>
        </div>
      </div>
    </div>
  );
}
