import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Mail, 
  Lock, 
  ArrowRight,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';

export default function AdminLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const userRef = doc(db, 'users', userCredential.user.uid);
      const userDoc = await getDoc(userRef);
      
      const role = userDoc.data()?.role;
      const isOverride = email === 'jakekalloor@gmail.com';

      if (role === 'admin' || isOverride) {
        navigate('/admin');
      } else {
        setError('Access denied. Administrator privileges required.');
        await auth.signOut();
      }
    } catch (err: any) {
      setError(err.message || 'Invalid email or password.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex items-center justify-center p-6 bg-mesh selection:bg-brand-gold selection:text-white">
      {/* Background Ambience */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            animate={{ 
              scale: [1, 1.2, 1],
              opacity: [0.1, 0.15, 0.1],
              rotate: [0, 90, 0]
            }}
            transition={{ duration: 15 + i * 5, repeat: Infinity, ease: "easeInOut" }}
            className="absolute bg-brand-gold rounded-full blur-[150px]"
            style={{
              width: `${500 + i * 100}px`,
              height: `${500 + i * 100}px`,
              left: `${(i * 40) % 100}%`,
              top: `${(i * 30) % 100}%`,
            }}
          />
        ))}
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 50 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 1.5, ease: [0.19, 1, 0.22, 1] }}
        className="w-full max-w-4xl bg-white/5 backdrop-blur-[60px] p-20 lg:p-24 rounded-[6rem] shadow-[0_100px_150px_rgba(0,0,0,0.5)] border border-white/20 relative z-10 flex flex-col md:flex-row gap-16 futuristic-glow"
      >
        <div className="md:w-5/12 flex flex-col justify-center">
          <motion.div 
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mb-12"
          >
            <div className="w-24 h-24 bg-brand-dark rounded-[2.5rem] flex items-center justify-center text-brand-gold mb-10 shadow-2xl border border-brand-gold/20 futuristic-glow">
              <ShieldCheck size={48} strokeWidth={1.5} className="shimmer-text" />
            </div>
            <h1 className="text-5xl md:text-6xl font-serif italic text-brand-dark mb-6 tracking-tighter leading-tight">
              Admin <br/>
              <span className="text-brand-gold shimmer-text">Login</span>
            </h1>
            <p className="text-[10px] uppercase tracking-[0.5em] font-black text-brand-dark/30 italic">Sign in to your admin account</p>
          </motion.div>
          
          <div className="space-y-6 pt-10 border-t border-brand-gold/10">
            <p className="text-xs text-brand-dark/40 italic leading-relaxed tracking-widest">
              Secure administrator portal for Aura by Dr. Merlin.
            </p>
          </div>
        </div>

        <form onSubmit={handleLogin} className="md:w-7/12 space-y-10 flex flex-col justify-center">
          <div className="space-y-8">
            <div className="group">
              <label className="block text-[10px] uppercase font-black tracking-[0.5em] text-brand-gold mb-4 ml-8 italic transition-all group-focus-within:translate-x-2">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-8 top-1/2 -translate-y-1/2 text-brand-gold/30 group-focus-within:text-brand-gold transition-all group-focus-within:scale-110" size={20} />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-20 pr-10 py-7 rounded-[3rem] bg-white/10 border border-brand-gold/10 focus:border-brand-gold focus:outline-none text-lg font-serif italic text-brand-dark transition-all shadow-inner placeholder:text-brand-dark/10"
                  placeholder="Email Address"
                  required
                />
              </div>
            </div>

            <div className="group">
              <label className="block text-[10px] uppercase font-black tracking-[0.5em] text-brand-gold mb-4 ml-8 italic transition-all group-focus-within:translate-x-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-8 top-1/2 -translate-y-1/2 text-brand-gold/30 group-focus-within:text-brand-gold transition-all group-focus-within:scale-110" size={20} />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-20 pr-10 py-7 rounded-[3rem] bg-white/10 border border-brand-gold/10 focus:border-brand-gold focus:outline-none text-lg font-serif italic text-brand-dark transition-all shadow-inner placeholder:text-brand-dark/10"
                  placeholder="Password"
                  required
                />
              </div>
            </div>
          </div>

          {error && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex items-center gap-4 p-8 bg-brand-rose/5 border border-brand-rose/10 rounded-[3rem] text-brand-rose text-[10px] uppercase font-black tracking-[0.3em]"
            >
              <AlertCircle size={20} />
              {error}
            </motion.div>
          )}

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="submit"
            disabled={loading}
            className="w-full gold-shimmer text-white py-8 rounded-full text-[12px] uppercase tracking-[0.6em] font-black shadow-2xl transition-all flex items-center justify-center gap-6 group futuristic-glow"
          >
            {loading ? 'Logging in...' : 'Login'} 
            {!loading && <ArrowRight size={20} className="group-hover:translate-x-2 transition-transform" />}
          </motion.button>
          
          <div className="relative flex items-center justify-center py-4">
             <div className="h-px flex-1 bg-brand-gold/10" />
             <span className="px-6 text-[9px] uppercase font-black text-brand-dark/20 tracking-[0.5em] italic">Secure Portal</span>
             <div className="h-px flex-1 bg-brand-gold/10" />
          </div>
        </form>
      </motion.div>
    </div>
  );
}
