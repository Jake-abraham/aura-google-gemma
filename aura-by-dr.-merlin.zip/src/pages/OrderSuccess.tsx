import React, { useEffect } from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, ShoppingBag, ArrowRight, Heart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import confetti from 'canvas-confetti';

export default function OrderSuccess() {
  const navigate = useNavigate();

  useEffect(() => {
    const duration = 4 * 1000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 3,
        angle: 60,
        spread: 70,
        origin: { x: 0 },
        colors: ['#C89B3C', '#FFFFFF', '#0A0A0A']
      });
      confetti({
        particleCount: 3,
        angle: 120,
        spread: 70,
        origin: { x: 1 },
        colors: ['#C89B3C', '#FFFFFF', '#0A0A0A']
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();
  }, []);

  return (
    <div className="min-h-screen relative overflow-hidden flex items-center justify-center p-6 bg-mesh selection:bg-brand-gold selection:text-white">
      {/* Background Ambience */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        {[...Array(4)].map((_, i) => (
          <motion.div
            key={i}
            animate={{ 
              scale: [1, 1.4, 1],
              opacity: [0.1, 0.2, 0.1],
              rotate: [0, 45, 0]
            }}
            transition={{ duration: 15 + i * 5, repeat: Infinity, ease: "easeInOut" }}
            className="absolute bg-brand-gold rounded-full blur-[180px]"
            style={{
              width: `${400 + i * 200}px`,
              height: `${400 + i * 200}px`,
              right: `${(i * 25) % 100}%`,
              top: `${(i * 15) % 100}%`,
            }}
          />
        ))}
      </div>

      <div className="max-w-3xl w-full text-center relative z-10">
        <motion.div
          initial={{ scale: 0, opacity: 0, rotate: -20 }}
          animate={{ scale: 1, opacity: 1, rotate: 0 }}
          transition={{ type: 'spring', damping: 12, stiffness: 80, delay: 0.5 }}
          className="w-32 h-32 bg-brand-dark text-brand-gold rounded-[2.5rem] flex items-center justify-center mx-auto mb-16 shadow-[0_40px_80px_rgba(0,0,0,0.4)] border border-brand-gold/30 futuristic-glow"
        >
          <CheckCircle2 size={64} strokeWidth={1} className="shimmer-text" />
        </motion.div>

        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 1.2, ease: [0.19, 1, 0.22, 1] }}
        >
          <motion.span 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="text-brand-gold uppercase tracking-[1em] text-[10px] font-black mb-8 block italic"
          >
            Chronicle Recorded
          </motion.span>
          <h1 className="text-7xl md:text-9xl font-serif italic mb-10 text-brand-dark tracking-tighter drop-shadow-2xl">
            Manifest <br className="hidden md:block"/> <span className="shimmer-text">Fulfilled</span>
          </h1>
          <p className="text-xl text-brand-dark/40 leading-relaxed max-w-xl mx-auto mb-20 italic font-medium tracking-tight">
            Your celestial transaction has been secured in the Merlin Heritage Ledger. Our master artisans have been summoned to orchestrate your treasures.
          </p>
        </motion.div>

        <motion.div 
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="bg-white/5 backdrop-blur-[50px] p-16 rounded-[5rem] shadow-[0_80px_150px_rgba(0,0,0,0.3)] border border-white/20 mb-20 futuristic-glow group overflow-hidden"
        >
          <div className="absolute inset-0 bg-mesh opacity-10 pointer-events-none" />
          <div className="relative z-10">
            <h3 className="text-[10px] uppercase tracking-[0.6em] font-black text-brand-gold mb-10 italic">Nexus Acquisition Index</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 text-left">
              <div className="space-y-3">
                <span className="text-[9px] text-brand-dark/30 uppercase tracking-[0.4em] font-black">Spatial Reference</span>
                <p className="text-2xl font-serif italic text-brand-dark tracking-tight">#AUR-{Math.random().toString(36).substring(7).toUpperCase()}</p>
              </div>
              <div className="space-y-3">
                <span className="text-[9px] text-brand-dark/30 uppercase tracking-[0.4em] font-black">Aura State</span>
                <p className="text-2xl font-serif italic text-brand-green tracking-tight flex items-center gap-3">
                  Materializing <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 2 }}><Heart size={20} fill="currentColor" /></motion.div>
                </p>
              </div>
            </div>
            <div className="h-px w-full bg-brand-gold/10 my-10" />
            <p className="text-xs text-brand-dark/30 italic tracking-[0.1em] font-medium leading-relaxed">
              A detailed ritual guide (invoice) has been transmitted to your digital cipher (email). Trace your journey in your Imperial Chamber.
            </p>
          </div>
        </motion.div>

        <motion.div 
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.3 }}
          className="flex flex-col md:flex-row gap-8 max-w-2xl mx-auto"
        >
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate('/')}
            className="flex-1 bg-brand-dark text-white py-8 rounded-full text-[10px] uppercase tracking-[0.5em] font-black shadow-2xl transition-all flex items-center justify-center gap-6 futuristic-glow"
          >
            Re-enter Nexus <ArrowRight size={20} />
          </motion.button>
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate('/account')}
            className="flex-1 bg-transparent border-2 border-brand-gold/20 text-brand-dark py-8 rounded-full text-[10px] uppercase tracking-[0.5em] font-black transition-all flex items-center justify-center gap-6 hover:border-brand-gold futuristic-glow-gold"
          >
            Open Imperial Bag <ShoppingBag size={20} />
          </motion.button>
        </motion.div>
      </div>
    </div>
  );
}
