import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart3, 
  Package, 
  ShoppingBag, 
  Plus, 
  Edit3, 
  Trash2, 
  ChevronRight,
  TrendingUp,
  Users,
  Image as ImageIcon,
  CheckCircle2,
  Clock,
  ExternalLink,
  LogOut,
  Globe
} from 'lucide-react';
import { 
  collection, 
  addDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc, 
  doc, 
  query, 
  orderBy,
  serverTimestamp 
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { PRODUCTS, type Product, CURRENCIES } from '../constants';
import { useNavigate } from 'react-router-dom';
import { signOut } from 'firebase/auth';
import { useShop } from '../context/ShopContext';

export default function AdminDashboard() {
  const { formatPrice } = useShop();
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'orders'>('overview');
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    category: 'Sarees',
    price: 0,
    priceINR: 0,
    priceAED: 0,
    image: '',
    description: '',
    name: '',
    isAvailable: true
  });
  const navigate = useNavigate();

  useEffect(() => {
    fetchProducts();
    fetchOrders();
  }, []);

  const fetchProducts = async () => {
    try {
      const q = query(collection(db, 'products'), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as Product[];
      setProducts(data.length > 0 ? data : PRODUCTS);
    } catch (error) {
      console.error("Fetch Products Error:", error);
      setProducts(PRODUCTS);
    }
  };

  const fetchOrders = async () => {
    try {
      const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setOrders(data);
    } catch (error) {
      console.error("Fetch Orders Error:", error);
    }
  };

  const handleAddProduct = async () => {
    try {
      await addDoc(collection(db, 'products'), {
        ...newProduct,
        createdAt: serverTimestamp(),
      });
      setIsAddingProduct(false);
      fetchProducts();
      setNewProduct({
        category: 'Sarees',
        price: 0,
        priceINR: 0,
        priceAED: 0,
        image: '',
        description: '',
        name: '',
        isAvailable: true
      });
    } catch (error) {
      alert("Crafting failed. Please check your admin connection.");
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (confirm('Are you sure you want to remove this creation from the studio?')) {
      await deleteDoc(doc(db, 'products', id));
      fetchProducts();
    }
  };

  const handleSignOut = async () => {
    await signOut(auth);
    navigate('/');
  };

  const stats = [
    { label: 'Hyper-Volume Sales', value: orders.length > 0 ? `₹${orders.reduce((a, b) => a + (b.total || 0), 0).toLocaleString()}` : '₹0', icon: TrendingUp, color: 'text-brand-green' },
    { label: 'Ethereal Orders', value: orders.length.toString(), icon: ShoppingBag, color: 'text-brand-gold' },
    { label: 'Elite Artisans', value: '12', icon: Users, color: 'text-brand-teal' },
  ];

  return (
    <div className="min-h-screen bg-mesh flex selection:bg-brand-gold selection:text-white">
      {/* Sidebar - Ethereal Glass */}
      <aside className="w-80 bg-white/5 backdrop-blur-[40px] text-brand-dark p-12 flex flex-col gap-16 sticky top-0 h-screen border-r border-white/20 shadow-2xl futuristic-glow">
        <div className="flex flex-col items-center text-center">
          <motion.div 
            whileHover={{ rotate: 360, scale: 1.1 }}
            transition={{ duration: 1 }}
            className="w-20 h-20 bg-brand-dark rounded-[2.5rem] flex items-center justify-center text-brand-gold mb-6 shadow-2xl font-serif text-3xl italic futuristic-glow"
          >
            A
          </motion.div>
          <h1 className="text-2xl font-serif tracking-[0.5em] uppercase font-black">Aura</h1>
          <p className="text-[10px] text-brand-gold tracking-[0.6em] uppercase font-black mt-3 italic">Nexus Console</p>
        </div>

        <nav className="flex flex-col gap-4">
          {[
            { id: 'overview', icon: BarChart3, label: 'Studio Pulse' },
            { id: 'products', icon: Package, label: 'Artifacts' },
            { id: 'orders', icon: ShoppingBag, label: 'Exchanges' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`flex items-center gap-6 px-10 py-6 rounded-[2rem] text-[10px] uppercase tracking-[0.4em] font-black transition-all relative group ${
                activeTab === item.id 
                  ? 'bg-brand-dark text-white shadow-2xl futuristic-glow' 
                  : 'text-brand-dark/20 hover:text-brand-dark hover:bg-white/10'
              }`}
            >
              <item.icon size={18} className={activeTab === item.id ? 'text-brand-gold' : ''} />
              <span className="relative z-10">{item.label}</span>
              {activeTab === item.id && (
                <motion.div layoutId="adminNav" className="absolute left-0 w-2 h-8 bg-brand-gold rounded-r-full futuristic-glow-gold" />
              )}
            </button>
          ))}
        </nav>

        <div className="mt-auto flex flex-col gap-6 pt-10 border-t border-brand-gold/10">
          <button 
            onClick={() => navigate('/')}
            className="flex items-center gap-4 text-[10px] uppercase tracking-[0.4em] text-brand-dark/40 hover:text-brand-gold transition-all font-black group"
          >
            <Globe size={16} className="group-hover:rotate-180 transition-transform duration-1000" /> Public Realm
          </button>
          <button 
            onClick={handleSignOut}
            className="flex items-center gap-4 text-[10px] uppercase tracking-[0.4em] text-brand-rose/60 hover:text-brand-rose transition-all font-black"
          >
            <LogOut size={16} /> Sever Link
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-20 overflow-y-auto">
        <header className="flex flex-col md:flex-row justify-between items-end mb-24 gap-8">
          <div>
            <h2 className="text-8xl font-serif text-brand-dark capitalize italic leading-none mb-6 drop-shadow-sm">{activeTab}</h2>
            <p className="text-brand-dark/30 text-xs tracking-[0.5em] uppercase font-black italic">Imperial Oversight & Management</p>
          </div>
          {activeTab === 'products' && (
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsAddingProduct(true)}
              className="gold-shimmer text-white px-16 py-7 rounded-full text-[10px] uppercase tracking-[0.5em] font-black shadow-2xl flex items-center gap-4 futuristic-glow"
            >
              <Plus size={20} /> Manifest Creation
            </motion.button>
          )}
        </header>

        <AnimatePresence mode="wait">
          {activeTab === 'overview' && (
            <motion.div 
              key="overview"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -30 }}
              className="space-y-24"
            >
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                {stats.map((stat, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: i * 0.1 }}
                    className="bg-white/5 backdrop-blur-3xl p-12 rounded-[4rem] shadow-2xl border border-white/20 hover:border-brand-gold/30 transition-all group relative overflow-hidden futuristic-glow"
                  >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-brand-gold/5 rounded-full blur-[50px] -mr-16 -mt-16 group-hover:bg-brand-gold/10 transition-all" />
                    <div className={`${stat.color} w-16 h-16 bg-white/10 rounded-[2rem] flex items-center justify-center mb-10 group-hover:rotate-12 transition-all shadow-xl`}>
                      <stat.icon size={28} />
                    </div>
                    <p className="text-brand-dark/30 text-[10px] uppercase tracking-[0.6em] font-black mb-3">{stat.label}</p>
                    <h3 className="text-6xl font-serif text-brand-dark italic tracking-tighter">{stat.value}</h3>
                  </motion.div>
                ))}
              </div>

              <div className="bg-white/5 backdrop-blur-3xl rounded-[5rem] shadow-2xl border border-white/20 p-16 futuristic-glow">
                <div className="flex justify-between items-center mb-16 px-4">
                  <h3 className="text-4xl font-serif italic text-brand-dark">Aura Pulse Live</h3>
                  <button 
                    onClick={() => setActiveTab('orders')}
                    className="text-[10px] uppercase tracking-[0.5em] font-black text-brand-gold hover:tracking-[0.7em] transition-all border-b border-brand-gold/20 pb-2"
                  >
                    All Acquisitions
                  </button>
                </div>
                <div className="space-y-8">
                  {orders.slice(0, 5).map((order, i) => (
                    <motion.div 
                      key={i} 
                      whileHover={{ x: 20 }}
                      className="flex items-center justify-between p-10 bg-white/5 backdrop-blur-2xl rounded-[3rem] border border-white/10 hover:border-brand-gold/30 transition-all group"
                    >
                      <div className="flex items-center gap-8">
                        <div className="w-20 h-20 bg-brand-dark text-brand-gold rounded-[2rem] flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform">
                          <ShoppingBag size={28} />
                        </div>
                        <div>
                          <p className="font-black text-lg text-brand-dark uppercase tracking-[0.3em]">Cipher #{order.id?.slice(-8).toUpperCase()}</p>
                          <p className="text-[10px] text-brand-dark/30 uppercase font-black mt-2 italic tracking-widest">{order.items?.length || 0} Artifacts &bull; {order.total ? formatPrice(order.total) : 'N/A'}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-16">
                        <div className="text-right">
                          <p className="text-[12px] uppercase font-black text-brand-dark mb-3 tracking-widest">{order.shipping?.name || 'Unknown Seeker'}</p>
                          <span className={`px-6 py-2 rounded-full text-[9px] uppercase font-black tracking-[0.3em] shadow-lg ${
                            order.status === 'processing' ? 'bg-brand-gold/10 text-brand-gold' : 'bg-brand-green/10 text-brand-green'
                          }`}>
                            {order.status}
                          </span>
                        </div>
                        <ChevronRight size={24} className="text-brand-gold group-hover:translate-x-3 transition-transform" />
                      </div>
                    </motion.div>
                  ))}
                  {orders.length === 0 && (
                    <div className="text-center py-40 text-brand-dark/20 italic font-serif text-3xl">Portal awaiting first connection...</div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'products' && (
            <motion.div 
              key="products"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-12"
            >
              {products.map((product) => (
                <motion.div 
                  key={product.id} 
                  layout
                  className="bg-white/5 backdrop-blur-3xl rounded-[4rem] overflow-hidden shadow-2xl border border-white/20 group flex flex-col futuristic-glow"
                >
                  <div className="aspect-[4/5] relative overflow-hidden border-b border-white/10">
                    <img src={product.image} className="w-full h-full object-cover transition-transform duration-[2s] group-hover:scale-125" />
                    <div className="absolute inset-0 bg-brand-dark/20 opacity-0 group-hover:opacity-100 transition-opacity" />
                    <div className="absolute top-8 right-8 flex gap-4 opacity-0 group-hover:opacity-100 transition-all translate-y-4 group-hover:translate-y-0">
                      <button className="bg-white/10 backdrop-blur-3xl p-5 rounded-[1.5rem] text-brand-gold hover:bg-brand-dark hover:text-white transition-all shadow-2xl border border-white/20">
                        <Edit3 size={20} />
                      </button>
                      <button 
                        onClick={() => handleDeleteProduct(product.id)}
                        className="bg-white/10 backdrop-blur-3xl p-5 rounded-[1.5rem] text-brand-rose hover:bg-brand-rose hover:text-white transition-all shadow-2xl border border-white/20"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  </div>
                  <div className="p-12 flex-1 flex flex-col">
                    <div className="flex justify-between items-center mb-6">
                      <span className="text-[10px] uppercase tracking-[0.5em] text-brand-gold font-black">{product.category}</span>
                      <div className="w-2 h-2 rounded-full bg-brand-green animate-pulse shadow-[0_0_10px_#10B981]" />
                    </div>
                    <h4 className="text-4xl font-serif text-brand-dark mb-10 leading-tight italic group-hover:text-brand-gold transition-colors">{product.name}</h4>
                    
                    <div className="mt-auto pt-8 border-t border-white/10 grid grid-cols-2 gap-8">
                      <div className="space-y-2">
                        <p className="text-[8px] uppercase tracking-[0.4em] text-brand-dark/30 font-black">Divine Value</p>
                        <p className="text-lg font-black tracking-tighter text-brand-dark">{formatPrice(product.price)}</p>
                      </div>
                      <div className="text-right flex items-end justify-end">
                        <button className="px-6 py-2 bg-white/5 border border-brand-gold/20 rounded-full text-[8px] uppercase tracking-[0.3em] font-black text-brand-gold hover:bg-brand-gold hover:text-white transition-all">Details</button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}

          {activeTab === 'orders' && (
            <motion.div 
              key="orders"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white/5 backdrop-blur-3xl rounded-[5rem] shadow-[0_50px_100px_rgba(0,0,0,0.2)] border border-white/20 overflow-hidden futuristic-glow"
            >
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-white/5 text-[10px] uppercase font-black tracking-[0.5em] text-brand-dark/40 border-b border-white/10">
                    <th className="px-12 py-10">Matrix Cipher</th>
                    <th className="px-12 py-10">Artisan / Seeker</th>
                    <th className="px-12 py-10">Transit Aura</th>
                    <th className="px-12 py-10">Celestial Value</th>
                    <th className="px-12 py-10">Moderation</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {orders.map((order, i) => (
                    <tr key={i} className="border-b border-white/5 hover:bg-white/10 transition-all group">
                      <td className="px-12 py-10">
                        <p className="font-black text-brand-dark uppercase tracking-[0.2em] group-hover:text-brand-gold transition-colors">#{order.id?.slice(-8).toUpperCase()}</p>
                        <p className="text-[8px] text-brand-dark/30 mt-2 uppercase font-black tracking-widest">{new Date(order.createdAt?.seconds * 1000).toLocaleDateString()}</p>
                      </td>
                      <td className="px-12 py-10">
                        <p className="font-black text-brand-dark tracking-widest uppercase">{order.shipping?.name}</p>
                        <p className="text-[10px] text-brand-dark/30 italic mt-1">{order.shipping?.email}</p>
                      </td>
                      <td className="px-12 py-10">
                        <span className={`px-6 py-2 rounded-full text-[9px] uppercase font-black tracking-[0.4em] shadow-inner ${
                          order.status === 'processing' ? 'bg-brand-gold/10 text-brand-gold' : 'bg-brand-green/10 text-brand-green'
                        }`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="px-12 py-10 font-serif italic text-2xl text-brand-dark tracking-tighter">{formatPrice(order.total)}</td>
                      <td className="px-12 py-10">
                        <button className="gold-shimmer text-white font-black text-[10px] uppercase tracking-[0.4em] px-8 py-3 rounded-full transition-all shadow-xl hover:scale-105">View</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {orders.length === 0 && (
                <div className="py-60 text-center flex flex-col items-center gap-10">
                  <div className="w-32 h-32 bg-white/5 rounded-full flex items-center justify-center text-brand-gold animate-pulse">
                    <ShoppingBag size={48} strokeWidth={1} />
                  </div>
                  <p className="text-brand-dark/20 uppercase tracking-[0.6em] font-black text-lg">Nexus Ledger Empty</p>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Add Product Modal */}
      <AnimatePresence>
        {isAddingProduct && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-8">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-brand-dark/60 backdrop-blur-3xl" 
              onClick={() => setIsAddingProduct(false)} 
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 50, rotateX: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0, rotateX: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 50, rotateX: 15 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="bg-white/10 backdrop-blur-[50px] w-full max-w-5xl relative z-10 rounded-[5rem] overflow-hidden shadow-[0_100px_150px_rgba(0,0,0,0.5)] p-20 border border-white/20 futuristic-glow"
            >
              <div className="absolute inset-0 bg-mesh opacity-10 pointer-events-none" />
              
              <h3 className="text-6xl font-serif mb-16 italic text-brand-dark text-center">Manifest New Artifact</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
                <div className="md:col-span-2 group">
                  <label className="block text-[10px] uppercase tracking-[0.5em] text-brand-gold font-black mb-4 ml-6 transition-all group-focus-within:tracking-[0.7em]">Creation Cipher (Name)</label>
                  <input 
                    type="text" 
                    value={newProduct.name}
                    onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
                    className="w-full px-12 py-7 rounded-[3rem] bg-white/5 border border-white/10 focus:border-brand-gold focus:outline-none text-xl transition-all text-brand-dark placeholder:text-brand-dark/20 italic font-serif" 
                    placeholder="Whisper the name..."
                  />
                </div>

                <div className="grid grid-cols-3 md:col-span-2 gap-6">
                  <div className="group">
                    <label className="block text-[10px] uppercase tracking-[0.5em] text-brand-gold font-black mb-4 ml-6 uppercase">Universal (USD)</label>
                    <div className="relative">
                      <span className="absolute left-8 top-1/2 -translate-y-1/2 text-brand-gold font-black">$</span>
                      <input 
                        type="number" 
                        value={newProduct.price}
                        onChange={(e) => setNewProduct({...newProduct, price: Number(e.target.value)})}
                        className="w-full pl-16 pr-8 py-7 rounded-[2.5rem] bg-white/5 border border-white/10 focus:border-brand-gold text-lg font-black tracking-tighter" 
                      />
                    </div>
                  </div>
                  <div className="group">
                    <label className="block text-[10px] uppercase tracking-[0.5em] text-brand-gold font-black mb-4 ml-6 uppercase">Imperial (INR)</label>
                    <div className="relative">
                      <span className="absolute left-8 top-1/2 -translate-y-1/2 text-brand-gold font-black">₹</span>
                      <input 
                        type="number" 
                        value={newProduct.priceINR}
                        onChange={(e) => setNewProduct({...newProduct, priceINR: Number(e.target.value)})}
                        className="w-full pl-16 pr-8 py-7 rounded-[2.5rem] bg-white/5 border border-white/10 focus:border-brand-gold text-lg font-black tracking-tighter" 
                      />
                    </div>
                  </div>
                  <div className="group">
                    <label className="block text-[10px] uppercase tracking-[0.5em] text-brand-gold font-black mb-4 ml-6 uppercase">Emirate (AED)</label>
                    <div className="relative">
                      <span className="absolute left-8 top-1/2 -translate-y-1/2 text-brand-gold font-black">د.إ</span>
                      <input 
                        type="number" 
                        value={newProduct.priceAED}
                        onChange={(e) => setNewProduct({...newProduct, priceAED: Number(e.target.value)})}
                        className="w-full pl-16 pr-8 py-7 rounded-[2.5rem] bg-white/5 border border-white/10 focus:border-brand-gold text-lg font-black tracking-tighter" 
                      />
                    </div>
                  </div>
                </div>

                <div className="group">
                  <label className="block text-[10px] uppercase tracking-[0.5em] text-brand-gold font-black mb-4 ml-6 uppercase">Nexus Category</label>
                  <select 
                    value={newProduct.category}
                    onChange={(e) => setNewProduct({...newProduct, category: e.target.value as any})}
                    className="w-full px-12 py-7 rounded-[3rem] bg-white/5 border border-white/10 focus:border-brand-gold focus:outline-none text-lg appearance-none cursor-pointer text-brand-dark italic font-serif"
                  >
                    <option className="bg-brand-dark text-white">Sarees</option>
                    <option className="bg-brand-dark text-white">Kurtas</option>
                    <option className="bg-brand-dark text-white">Festive Wear</option>
                    <option className="bg-brand-dark text-white">Bridal</option>
                  </select>
                </div>

                <div className="group">
                  <label className="block text-[10px] uppercase tracking-[0.5em] text-brand-gold font-black mb-4 ml-6 uppercase">Visual Essence Link</label>
                  <div className="flex gap-6">
                    <input 
                      type="text" 
                      value={newProduct.image}
                      onChange={(e) => setNewProduct({...newProduct, image: e.target.value})}
                      className="flex-1 px-12 py-7 rounded-[3rem] bg-white/5 border border-white/10 focus:border-brand-gold focus:outline-none text-[10px] uppercase font-black" 
                      placeholder="Artifact Matrix URL..."
                    />
                    <div className="w-20 h-20 bg-white/10 rounded-[2rem] flex items-center justify-center border border-white/10 overflow-hidden shadow-2xl">
                      {newProduct.image ? <img src={newProduct.image} className="w-full h-full object-cover" /> : <ImageIcon className="text-brand-gold/30" />}
                    </div>
                  </div>
                </div>

                <div className="md:col-span-2 group">
                  <label className="block text-[10px] uppercase tracking-[0.5em] text-brand-gold font-black mb-4 ml-6 uppercase">Chronicle Narrative</label>
                  <textarea 
                    rows={3}
                    value={newProduct.description}
                    onChange={(e) => setNewProduct({...newProduct, description: e.target.value})}
                    className="w-full px-12 py-7 rounded-[3rem] bg-white/5 border border-white/10 focus:border-brand-gold focus:outline-none text-lg text-brand-dark resize-none transition-all placeholder:italic font-serif" 
                    placeholder="Weave the story..."
                  />
                </div>
              </div>

              <div className="flex gap-8">
                <button 
                  onClick={() => setIsAddingProduct(false)}
                  className="flex-1 px-12 py-8 border border-white/20 text-brand-dark/20 rounded-full text-[10px] uppercase tracking-[0.5em] font-black hover:bg-white/10 hover:text-brand-dark transition-all"
                >
                  Dissolve Manifest
                </button>
                <motion.button 
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleAddProduct}
                  className="flex-1 px-12 py-8 gold-shimmer text-white rounded-full text-[12px] uppercase tracking-[0.6em] font-black shadow-2xl overflow-hidden relative group futuristic-glow"
                >
                  <span className="relative z-10">Enshrine in Studio</span>
                  <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
                </motion.button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

