import React from 'react';
import { motion } from 'motion/react';
import { 
  Mail, 
  Phone, 
  MapPin, 
  MessageCircle, 
  Clock, 
  ArrowRight,
  Send
} from 'lucide-react';

export default function Contact() {
  return (
    <div className="min-h-screen bg-mesh pt-48 pb-32 px-6 relative overflow-hidden selection:bg-brand-gold selection:text-white">
      {/* Background Ambience */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-0 right-0 w-[1000px] h-[1000px] bg-brand-gold/5 rounded-full blur-[200px] -mr-[30%] -mt-[20%]" />
        <div className="absolute bottom-0 left-0 w-[800px] h-[800px] bg-brand-dark/5 rounded-full blur-[200px] -ml-[20%] -mb-[20%]" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <header className="text-center mb-32">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center justify-center gap-6 mb-8"
          >
            <div className="h-px w-12 bg-brand-gold/30" />
            <span className="text-brand-gold uppercase tracking-[0.8em] text-[10px] font-black italic">Transmission Protocol</span>
            <div className="h-px w-12 bg-brand-gold/30" />
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.5, ease: [0.19, 1, 0.22, 1] }}
            className="text-6xl md:text-9xl font-serif text-brand-dark italic tracking-tighter shimmer-text"
          >
            Invoke the <br className="hidden md:block"/> Ethereal Studio
          </motion.h1>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-20 items-start">
          {/* Info Column */}
          <div className="lg:col-span-5 space-y-20">
            <div className="grid grid-cols-1 gap-10">
              {[
                { 
                  icon: Mail, 
                  label: 'Digital Cipher', 
                  value: 'studio@aurabymerlin.com', 
                  desc: 'Asynchronous responses within 24 standard hours',
                  link: 'mailto:studio@aurabymerlin.com'
                },
                { 
                  icon: MessageCircle, 
                  label: 'Matrix Pulse', 
                  value: '+91 98765 43210', 
                  desc: 'Sync active 10 AM - 8 PM IST',
                  link: 'https://wa.me/919876543210'
                },
                { 
                  icon: MapPin, 
                  label: 'Physical Nexus', 
                  value: 'Hauz Khas Village', 
                  desc: 'Studio 42, New Delhi Territory',
                  link: '#'
                }
              ].map((item, idx) => (
                <motion.a
                  key={idx}
                  href={item.link}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="group flex items-start gap-10 p-10 bg-white/5 backdrop-blur-3xl rounded-[3rem] border border-white/20 hover:border-brand-gold/40 transition-all shadow-2xl relative overflow-hidden futuristic-glow"
                >
                  <div className="absolute inset-0 bg-mesh opacity-5 group-hover:opacity-10 transition-opacity" />
                  <div className="w-20 h-20 bg-brand-dark rounded-[1.8rem] flex items-center justify-center text-brand-gold shadow-2xl group-hover:rotate-12 transition-all relative z-10 border border-brand-gold/20 futuristic-glow">
                    <item.icon size={28} strokeWidth={1.5} />
                  </div>
                  <div className="relative z-10 flex-1">
                    <h3 className="text-[10px] uppercase tracking-[0.5em] font-black text-brand-dark/40 mb-3 italic">{item.label}</h3>
                    <p className="text-3xl font-serif text-brand-dark mb-2 italic tracking-tight group-hover:text-brand-gold transition-colors">{item.value}</p>
                    <p className="text-[10px] text-brand-dark/30 font-black uppercase tracking-[0.3em]">{item.desc}</p>
                  </div>
                </motion.a>
              ))}
            </div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="bg-brand-dark p-16 rounded-[4rem] text-white relative overflow-hidden shadow-2xl group border border-white/10 futuristic-glow"
            >
              <div className="absolute inset-0 bg-mesh opacity-20" />
              <div className="relative z-10">
                <div className="flex items-center gap-4 mb-8">
                  <Clock className="text-brand-gold animate-spin-slow" size={32} />
                  <span className="h-px w-12 bg-brand-gold" />
                </div>
                <h3 className="text-4xl font-serif italic mb-6 tracking-tight">Concierge Oracle</h3>
                <p className="text-white/50 leading-relaxed mb-12 text-sm italic tracking-widest max-w-sm">
                  Seeking a bespoke adjustment or orchestration for a sacred union? Our elite concierge awaits your command.
                </p>
                <button className="flex items-center gap-6 text-brand-gold text-[10px] uppercase tracking-[0.6em] font-black hover:tracking-[0.8em] transition-all gold-shimmer-text">
                  Synchronize Consultation <ArrowRight size={20} />
                </button>
              </div>
              <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-brand-gold/10 rounded-full blur-[100px] group-hover:scale-125 transition-transform duration-1000" />
            </motion.div>
          </div>

          {/* Form Column */}
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-1"
          />
          
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-6 bg-white/5 backdrop-blur-[50px] p-16 md:p-24 rounded-[6rem] shadow-[0_100px_150px_rgba(0,0,0,0.3)] border border-white/20 relative futuristic-glow"
          >
            <div className="mb-16">
              <h3 className="text-5xl font-serif italic text-brand-dark mb-4 tracking-tighter">Manifest Inquiry</h3>
              <p className="text-xs text-brand-dark/30 italic tracking-widest">Provide the seeds of your message to initiate the response cycle.</p>
            </div>

            <form className="space-y-10">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div className="group">
                  <label className="block text-[10px] uppercase font-black tracking-[0.4em] text-brand-gold mb-4 ml-8 italic group-focus-within:translate-x-2 transition-all">Imperial Identity</label>
                  <input 
                    type="text" 
                    className="w-full px-10 py-7 rounded-[3rem] bg-white/10 border border-brand-gold/10 focus:border-brand-gold focus:outline-none text-lg font-serif italic text-brand-dark transition-all shadow-inner placeholder:text-brand-dark/10"
                    placeholder="Signature Name"
                  />
                </div>
                <div className="group">
                  <label className="block text-[10px] uppercase font-black tracking-[0.4em] text-brand-gold mb-4 ml-8 italic group-focus-within:translate-x-2 transition-all">Secure Address</label>
                  <input 
                    type="email" 
                    className="w-full px-10 py-7 rounded-[3rem] bg-white/10 border border-brand-gold/10 focus:border-brand-gold focus:outline-none text-lg font-serif italic text-brand-dark transition-all shadow-inner placeholder:text-brand-dark/10"
                    placeholder="Cipher Email"
                  />
                </div>
              </div>

              <div className="group">
                <label className="block text-[10px] uppercase font-black tracking-[0.4em] text-brand-gold mb-4 ml-8 italic group-focus-within:translate-x-2 transition-all">Inquiry Sphere</label>
                <div className="relative">
                  <select className="w-full px-10 py-7 rounded-[3rem] bg-white/10 border border-brand-gold/10 focus:border-brand-gold focus:outline-none text-lg font-serif italic text-brand-dark transition-all appearance-none cursor-pointer shadow-inner">
                    <option>Bespoke Fitting Oracle</option>
                    <option>Artifact Fulfillment Status</option>
                    <option>Imperial Union Consultation</option>
                    <option>General Matrix Inquiry</option>
                  </select>
                  <div className="absolute right-10 top-1/2 -translate-y-1/2 pointer-events-none text-brand-gold/30">
                    <ArrowRight size={20} className="rotate-90" />
                  </div>
                </div>
              </div>

              <div className="group">
                <label className="block text-[10px] uppercase font-black tracking-[0.4em] text-brand-gold mb-4 ml-8 italic group-focus-within:translate-x-2 transition-all">Manifest Message</label>
                <textarea 
                  rows={6}
                  className="w-full px-12 py-8 rounded-[4rem] bg-white/10 border border-brand-gold/10 focus:border-brand-gold focus:outline-none text-lg font-serif italic text-brand-dark transition-all resize-none shadow-inner placeholder:text-brand-dark/10"
                  placeholder="Articulate your journey through the Aura..."
                />
              </div>

              <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full gold-shimmer text-white py-8 rounded-full text-[12px] uppercase tracking-[0.6em] font-black shadow-2xl transition-all flex items-center justify-center gap-6 futuristic-glow"
              >
                Transmit to Nexus <Send size={24} className="shimmer-text" />
              </motion.button>
            </form>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
