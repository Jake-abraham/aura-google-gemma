import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, useScroll, useTransform, AnimatePresence } from 'motion/react';
import { 
  ShoppingBag, 
  ArrowRight,
  Heart,
  Search,
  X,
  Globe,
  CheckCircle2
} from 'lucide-react';
import { COLLECTIONS, PRODUCTS, type Product } from '../constants';
import { useShop } from '../context/ShopContext';

const LocationBanner = () => {
  const { currency, setCurrency } = useShop();
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  return (
    <motion.div 
      initial={{ opacity: 0, y: -50 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed top-0 left-0 w-full z-[110] bg-brand-dark text-white px-6 py-2 text-[10px] uppercase tracking-widest font-bold flex items-center justify-center gap-4"
    >
      <Globe size={12} className="text-brand-gold" />
      <span>Ethereal Pricing: You are viewing in {currency}</span>
      <button 
        onClick={() => setIsVisible(false)}
        className="ml-4 hover:text-brand-gold transition-colors"
      >
        <X size={12} />
      </button>
    </motion.div>
  );
};

const Hero = () => {
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 500], [0, 200]);
  const opacity = useTransform(scrollY, [0, 300], [1, 0]);
  const navigate = useNavigate();

  return (
    <section className="relative h-screen w-full overflow-hidden flex items-center justify-center bg-mesh">
      {/* Dynamic Floating Particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-[1]">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="floating-particle"
            initial={{ 
              x: Math.random() * 100 + '%', 
              y: Math.random() * 100 + '%',
              opacity: 0,
              scale: Math.random() * 0.5 + 0.5 
            }}
            animate={{ 
              y: [null, -100 + '%'],
              opacity: [0, 0.5, 0],
              transition: { 
                duration: Math.random() * 5 + 5, 
                repeat: Infinity, 
                delay: Math.random() * 5 
              }
            }}
          />
        ))}
      </div>

      <motion.div 
        style={{ y: y1 }}
        className="absolute inset-0 z-0"
      >
        <div className="absolute inset-0 bg-brand-dark/20 z-10" />
        <motion.div 
          animate={{ scale: [1, 1.05, 1] }} 
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="w-full h-full"
        >
          <img 
            src="https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=1920" 
            alt="Hero Model"
            className="w-full h-full object-cover grayscale-[0.3] brightness-75 scale-110"
            referrerPolicy="no-referrer"
          />
        </motion.div>
        {/* Futuristic Overlay Mask */}
        <div className="absolute inset-0 bg-gradient-to-t from-brand-cream/90 via-transparent to-brand-dark/30 z-[15]" />
        
        {/* Flowing Fabric Effect (Abstract SVG) */}
        <div className="absolute bottom-0 left-0 w-full h-[60%] z-[16] opacity-30 pointer-events-none overflow-hidden">
          <motion.svg
            viewBox="0 0 1440 320"
            className="w-[200%] h-full"
            animate={{ x: [-1440, 0] }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          >
            <path
              fill="#C89B3C"
              fillOpacity="0.1"
              d="M0,192L48,197.3C96,203,192,213,288,229.3C384,245,480,267,576,250.7C672,235,768,181,864,181.3C960,181,1056,235,1152,234.7C1248,235,1344,181,1392,154.7L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
            ></path>
          </motion.svg>
        </div>
      </motion.div>

      <motion.div 
        style={{ opacity }}
        className="relative z-20 text-center px-6"
      >
        <motion.div
           initial={{ opacity: 0, scale: 0.95 }}
           animate={{ opacity: 1, scale: 1 }}
           transition={{ duration: 1.8, ease: [0.19, 1, 0.22, 1] }}
           className="mb-8"
        >
          <motion.span 
            initial={{ opacity: 0, tracking: '0.2em' }}
            animate={{ opacity: 1, tracking: '0.8em' }}
            transition={{ delay: 0.5, duration: 1.5 }}
            className="text-[10px] md:text-xs uppercase text-white/90 mb-8 block font-black border-y border-white/20 py-6 max-w-fit mx-auto px-10 glass-card"
          >
            Aura Studio Legacy
          </motion.span>
          <h2 className="text-7xl md:text-[12rem] font-serif text-white tracking-tighter leading-none mb-12 drop-shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
            <motion.span
              initial={{ x: -150, opacity: 0, skewX: 20 }}
              animate={{ x: 0, opacity: 1, skewX: 0 }}
              transition={{ delay: 0.7, duration: 1.5, ease: [0.19, 1, 0.22, 1] }}
              className="block shimmer-text"
            >
              Divine
            </motion.span>
            <motion.span
              initial={{ x: 150, opacity: 0, skewX: -20 }}
              animate={{ x: 0, opacity: 1, skewX: 0 }}
              transition={{ delay: 0.9, duration: 1.5, ease: [0.19, 1, 0.22, 1] }}
              className="block italic text-brand-gold -mt-6 md:-mt-12 text-glow"
            >
              Drapery
            </motion.span>
          </h2>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.4, duration: 1 }}
          className="flex flex-col md:flex-row gap-12 justify-center items-center"
        >
          <motion.button 
            whileHover={{ scale: 1.05, boxShadow: '0 20px 40px rgba(200,155,60,0.4)' }}
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate('/collections')}
            className="gold-shimmer text-white px-20 py-8 rounded-full text-[12px] uppercase tracking-[0.5em] font-black group relative overflow-hidden"
          >
            <span className="relative z-10 transition-all group-hover:tracking-[0.8em]">Explore Studio</span>
            <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
          </motion.button>
          <motion.button 
            whileHover={{ backgroundColor: 'rgba(255,255,255,1)', color: '#111' }}
            onClick={() => {
              const el = document.getElementById('collections');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="px-20 py-8 rounded-full bg-white/5 backdrop-blur-3xl border border-white/20 text-white text-[12px] uppercase tracking-[0.5em] font-black transition-all flex items-center gap-4"
          >
            Our Heritage
            <ArrowRight size={16} className="text-brand-gold" />
          </motion.button>
        </motion.div>
      </motion.div>

      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-4">
        <motion.span 
          animate={{ opacity: [0.3, 0.6, 0.3] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="text-white/40 text-[8px] uppercase tracking-[0.5em] font-black"
        >
          Inhale
        </motion.span>
        <motion.div 
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="w-px h-16 bg-gradient-to-b from-white to-transparent"
        />
      </div>
    </section>
  );
};

const CollectionsSection = () => {
  const navigate = useNavigate();
  return (
    <section id="collections" className="py-40 px-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-end mb-24 gap-8">
        <div>
          <motion.span 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            className="text-brand-gold uppercase tracking-[0.6em] text-[10px] mb-4 block font-black"
          >
            Ethereal Curation
          </motion.span>
          <motion.h2 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-8xl font-serif text-brand-dark italic"
          >
            Featured Aura
          </motion.h2>
        </div>
        <motion.button 
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          onClick={() => navigate('/collections')}
          className="flex items-center gap-6 group text-[10px] uppercase tracking-[0.4em] font-black hover:text-brand-gold transition-colors"
        >
          Explore Full Studio <ArrowRight size={18} className="group-hover:translate-x-4 transition-transform duration-500" />
        </motion.button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
        {COLLECTIONS.map((collection, idx) => (
          <motion.div
            key={collection.id}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1, duration: 0.8 }}
            onClick={() => navigate('/collections')}
            className="group cursor-pointer relative"
          >
            <div className="relative overflow-hidden rounded-[3rem] aspect-[3/4] mb-8 shadow-2xl border border-brand-gold/10">
              <img 
                src={collection.image} 
                alt={collection.name} 
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-brand-dark/20 group-hover:bg-brand-dark/40 transition-colors duration-700" />
              <div className="absolute inset-0 flex items-center justify-center translate-y-8 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-700">
                <div className="w-16 h-16 bg-white/95 rounded-full flex items-center justify-center text-brand-dark">
                  <ArrowRight size={24} />
                </div>
              </div>
              <div className="absolute bottom-12 left-10 right-10 text-white">
                <h3 className="text-3xl font-serif mb-3 italic">{collection.name}</h3>
                <div className="h-px w-0 group-hover:w-full bg-brand-gold transition-all duration-700" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

const ProductCard = ({ product, onQuickView }: { product: Product; onQuickView: (p: Product) => void; key?: React.Key }) => {
  const { addToCart, formatPrice } = useShop();
  const [justAdded, setJustAdded] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 2000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="group cursor-pointer relative"
      onClick={() => onQuickView(product)}
    >
      <div className="relative aspect-[3/4] overflow-hidden rounded-[3rem] mb-8 bg-white shadow-2xl border border-brand-gold/10 futuristic-glow group-hover:border-brand-gold/40 transition-all duration-700">
        <AnimatePresence mode="wait">
          <motion.img 
            key={isHovered ? 'hover' : 'default'}
            src={isHovered && product.image2 ? product.image2 : product.image} 
            alt={product.name}
            initial={{ opacity: 0, scale: 1 }}
            animate={{ opacity: 1, scale: isHovered ? 1.15 : 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="w-full h-full object-cover grayscale-[0.2] group-hover:grayscale-0 transition-all"
            referrerPolicy="no-referrer"
          />
        </AnimatePresence>
        
        {/* Divine Actions Overlay */}
        <div className={`absolute inset-0 bg-brand-dark/30 backdrop-blur-[4px] transition-all duration-700 flex flex-col items-center justify-center gap-6 ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
          <div className="flex gap-4 transform translate-y-10 group-hover:translate-y-0 transition-transform duration-700">
            <motion.button 
              whileHover={{ scale: 1.1, backgroundColor: '#C89B3C', color: '#fff' }}
              whileTap={{ scale: 0.9 }}
              onClick={(e) => { e.stopPropagation(); onQuickView(product); }}
              className="w-16 h-16 bg-white/95 rounded-full flex items-center justify-center text-brand-dark shadow-2xl transition-all"
            >
              <Search size={22} strokeWidth={1.5} />
            </motion.button>
            <motion.button 
              whileHover={{ scale: 1.1, backgroundColor: '#C89B3C', color: '#fff' }}
              whileTap={{ scale: 0.9 }}
              onClick={handleAdd}
              className={`w-16 h-16 bg-white/95 rounded-full flex items-center justify-center text-brand-dark shadow-2xl transition-all ${justAdded ? 'bg-brand-green text-white scale-110 shadow-[0_0_20px_rgba(58,157,93,0.5)]' : ''}`}
            >
              {justAdded ? <CheckCircle2 size={22} strokeWidth={1.5} /> : <ShoppingBag size={22} strokeWidth={1.5} />}
            </motion.button>
          </div>
          <motion.span className="text-[10px] uppercase tracking-[0.4em] font-black text-white transform translate-y-10 group-hover:translate-y-0 transition-transform duration-700 delay-100 italic">
            Divine Inquiry
          </motion.span>
        </div>

        <div className="absolute top-8 right-8">
          <button 
            onClick={(e) => e.stopPropagation()}
            className="bg-white/95 backdrop-blur-md p-4 rounded-full text-brand-dark hover:text-brand-rose hover:scale-125 transition-all shadow-2xl translate-x-20 group-hover:translate-x-0 duration-700"
          >
            <Heart size={18} strokeWidth={1.5} />
          </button>
        </div>

        {/* Level Indicator */}
        <div className="absolute bottom-10 right-10">
          <div className="h-1 w-12 bg-white/20 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: isHovered ? '100%' : '20%' }}
              className="h-full bg-brand-gold"
            />
          </div>
        </div>
      </div>

      <div className="text-center px-4">
        <span className="text-[10px] font-black text-brand-gold uppercase tracking-[0.6em] mb-4 block opacity-40 group-hover:opacity-100 transition-all">
          {product.category}
        </span>
        <h3 className="text-3xl font-serif mb-4 text-brand-dark italic group-hover:text-brand-gold group-hover:translate-y-[-4px] transition-all duration-700">
          {product.name}
        </h3>
        <div className="h-px w-8 bg-brand-gold/20 mx-auto mb-4 group-hover:w-20 transition-all duration-700" />
        <p className="text-brand-dark font-black tracking-widest text-sm flex items-center justify-center gap-4">
          <span className="opacity-20 line-through text-[10px]">
            {formatPrice(product.price * 1.5, product)}
          </span>
          <span className="group-hover:scale-110 transition-transform inline-block">
            {formatPrice(product.price, product)}
          </span>
        </p>
      </div>
    </motion.div>
  );
};

const CategoriesSection = () => {
  const navigate = useNavigate();
  const categories = [
    { name: 'Bridal Couture', image: 'https://images.unsplash.com/photo-1594465919760-441fe5908ab0?auto=format&fit=crop&q=80&w=800', desc: 'The ultimate divine threads.' },
    { name: 'Festive Aura', image: 'https://images.unsplash.com/photo-1610189012906-40014a60ecc2?auto=format&fit=crop&q=80&w=800', desc: 'Radiance for every celebration.' },
    { name: 'Regal Sarees', image: 'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&q=80&w=800', desc: 'Timeless grace in every fold.' }
  ];

  return (
    <section className="py-40 px-6 max-w-7xl mx-auto">
      <div className="text-center mb-24">
        <motion.span 
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          className="text-brand-gold uppercase tracking-[0.8em] text-[10px] mb-6 block font-black border-b border-brand-gold/20 pb-4 max-w-fit mx-auto"
        >
          Curated Essences
        </motion.span>
        <h2 className="text-5xl md:text-8xl font-serif text-brand-dark italic">Featured Categories</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
        {categories.map((cat, idx) => (
          <motion.div
            key={cat.name}
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.2, duration: 1 }}
            onClick={() => navigate('/collections')}
            className="group cursor-pointer relative overflow-hidden rounded-[3rem] aspect-[4/5] shadow-2xl border border-white/10 futuristic-glow"
          >
            <img 
              src={cat.image} 
              alt={cat.name} 
              className="w-full h-full object-cover transition-transform duration-[1.5s] group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-brand-dark via-brand-dark/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-700" />
            
            <div className="absolute inset-0 p-12 flex flex-col justify-end">
              <span className="text-brand-gold uppercase tracking-[0.4em] text-[10px] font-black mb-4 group-hover:tracking-[0.6em] transition-all duration-500">{cat.desc}</span>
              <h3 className="text-4xl font-serif text-white italic mb-6 group-hover:text-brand-gold transition-colors">{cat.name}</h3>
              <div className="w-12 h-px bg-brand-gold group-hover:w-full transition-all duration-700" />
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

const PromoBanner = () => {
  const navigate = useNavigate();
  return (
    <section className="py-20 px-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        className="max-w-7xl mx-auto relative rounded-[4rem] overflow-hidden aspect-[16/7] shadow-2xl futuristic-glow group cursor-pointer"
        onClick={() => navigate('/collections')}
      >
        <img 
          src="https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&q=80&w=1920" 
          alt="Festive Collection"
          className="w-full h-full object-cover grayscale-[0.2] brightness-50 group-hover:scale-105 transition-transform duration-[2s]"
        />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-12">
          <motion.span 
            animate={{ tracking: ['0.4em', '0.8em', '0.4em'] }}
            transition={{ duration: 4, repeat: Infinity }}
            className="text-brand-gold uppercase text-[12px] font-black mb-8"
          >
            Spring // Summer 2026
          </motion.span>
          <h2 className="text-5xl md:text-9xl font-serif text-white italic mb-12 drop-shadow-2xl">The Ethereal Bride</h2>
          <button className="px-20 py-8 rounded-full gold-shimmer text-white text-[12px] uppercase tracking-[0.6em] font-black futuristic-glow">
            Discover the Aura
          </button>
        </div>
      </motion.div>
    </section>
  );
};

const AboutSection = () => {
  const navigate = useNavigate();
  return (
    <section id="about" className="py-40 px-6 overflow-hidden relative bg-white/30 backdrop-blur-3xl">
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-32">
        <div className="relative flex-1">
          <motion.div 
            initial={{ opacity: 0, x: -100 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 1.5, ease: [0.19, 1, 0.22, 1] }}
            className="aspect-[4/5] rounded-[4rem] overflow-hidden shadow-[0_50px_100px_rgba(0,0,0,0.2)] futuristic-glow relative z-10"
          >
            <img 
              src="https://images.unsplash.com/photo-1594465919760-441fe5908ab0?auto=format&fit=crop&q=80&w=800" 
              alt="About Aura"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, y: 100 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 1.5 }}
            className="absolute -bottom-20 -right-12 w-80 h-80 glass-card rounded-[3rem] p-12 flex flex-col items-center justify-center text-center z-20 shadow-2xl border border-white/20"
          >
            <Globe className="text-brand-gold mb-6 animate-spin-slow" size={40} />
            <h4 className="text-5xl font-serif text-brand-dark mb-4">30+</h4>
            <span className="text-[10px] uppercase font-black tracking-[0.4em] text-brand-dark/40">Years of Divine <br /> Legacy Artistry</span>
          </motion.div>
        </div>

        <div className="flex-1 space-y-12">
          <div>
            <div className="flex items-center gap-6 mb-8">
              <div className="h-px w-16 bg-brand-gold" />
              <span className="text-brand-gold uppercase tracking-[0.6em] text-[10px] font-black">Celestial Heritage</span>
            </div>
            <h2 className="text-6xl md:text-8xl font-serif text-brand-dark mb-10 italic leading-[1.1]">Inspired by You, <br /> Crafted for Forever.</h2>
            <p className="text-brand-dark/70 leading-relaxed text-2xl italic font-serif border-l-4 border-brand-gold/30 pl-10">
              "Aura is a digital-first high-luxury house celebrating the feminine spirit through threads of artificial serenity."
            </p>
          </div>
          <p className="text-brand-dark/60 leading-loose text-lg font-light tracking-[0.05em] max-w-xl">
            Founded by Dr. Merlin, Aura merges medical precision with ethereal aesthetics. Our garments are not just fabric; they are programmable experiences of grace and architectural beauty.
          </p>
          <div className="flex flex-wrap gap-8 pt-6">
            <button 
              onClick={() => navigate('/collections')}
              className="bg-brand-dark text-white px-16 py-7 rounded-full text-[10px] uppercase tracking-[0.4em] font-black hover:bg-brand-gold transition-all shadow-2xl futuristic-glow"
            >
              Our Philosophy
            </button>
            <button className="border border-brand-gold/30 text-brand-gold px-16 py-7 rounded-full text-[10px] uppercase tracking-[0.4em] font-black hover:bg-brand-cream transition-all group backdrop-blur-xl">
              Watch Manifest <ArrowRight size={14} className="inline-block ml-4 group-hover:translate-x-2 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export const QuickViewModal = ({ product, isOpen, onClose }: { product: Product; isOpen: boolean; onClose: () => void }) => {
  const { addToCart, formatPrice } = useShop();

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[120] flex items-center justify-center p-6 md:p-12"
        >
          <motion.div 
            className="absolute inset-0 bg-brand-dark/40 backdrop-blur-2xl"
            onClick={onClose}
          />
          <motion.div 
            initial={{ scale: 0.8, rotateX: 15, opacity: 0 }}
            animate={{ scale: 1, rotateX: 0, opacity: 1 }}
            exit={{ scale: 0.8, rotateX: 15, opacity: 0 }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="bg-white/10 backdrop-blur-3xl w-full max-w-6xl relative z-10 rounded-[4rem] overflow-hidden shadow-[0_50px_100px_rgba(0,0,0,0.3)] flex flex-col md:flex-row border border-white/20"
          >
            <div className="absolute inset-0 bg-mesh opacity-10 pointer-events-none" />
            
            <button 
              onClick={onClose}
              className="absolute top-10 right-10 z-20 bg-white/10 backdrop-blur-3xl p-5 rounded-full hover:bg-brand-dark hover:text-white transition-all shadow-2xl border border-white/10 group"
            >
              <X size={24} className="group-hover:rotate-90 transition-transform duration-500" />
            </button>

            <div className="md:w-1/2 aspect-[4/5] md:aspect-auto overflow-hidden relative group/modal-img">
              <motion.img 
                initial={{ scale: 1.1 }}
                animate={{ scale: 1 }}
                src={product.image} 
                alt={product.name} 
                className="w-full h-full object-cover transition-transform duration-1000 group-hover/modal-img:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-brand-dark/20 to-transparent" />
            </div>

            <div className="md:w-1/2 p-12 md:p-20 flex flex-col justify-center relative">
              <div className="mb-10">
                <div className="flex items-center gap-4 mb-6">
                  <div className="h-px w-10 bg-brand-gold" />
                  <span className="text-brand-gold uppercase tracking-[0.5em] text-[10px] font-black">
                    {product.category}
                  </span>
                </div>
                <h2 className="text-5xl md:text-7xl font-serif mb-8 text-brand-dark leading-tight italic drop-shadow-sm">{product.name}</h2>
                <div className="flex items-baseline gap-6 mb-10">
                  <p className="text-4xl font-black text-brand-dark tracking-tighter">{formatPrice(product.price, product)}</p>
                  <p className="text-xl text-brand-dark/20 line-through font-bold">{formatPrice(product.price * 1.4, product)}</p>
                </div>
                <div className="space-y-6 max-w-md">
                  <p className="text-brand-dark/70 leading-relaxed italic text-lg font-serif border-l-2 border-brand-gold/30 pl-6">
                    {product.description}
                  </p>
                </div>
              </div>

              <div className="space-y-6">
                <motion.button 
                  whileHover={{ scale: 1.02, boxShadow: '0 20px 40px rgba(200,155,60,0.3)' }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    addToCart(product);
                    onClose();
                  }}
                  className="w-full gold-shimmer text-white py-6 rounded-full text-[12px] uppercase tracking-[0.4em] font-black hover:shadow-2xl transition-all shadow-xl relative overflow-hidden group/btn"
                >
                  <span className="relative z-10 transition-all group-hover/btn:tracking-[0.6em]">Secure this Artifact</span>
                  <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover/btn:translate-x-[100%] transition-transform duration-1000" />
                </motion.button>
                <div className="flex gap-4">
                  <button className="flex-1 bg-white/5 backdrop-blur-xl border border-brand-gold/30 py-6 rounded-full text-[10px] uppercase tracking-widest font-black hover:bg-brand-dark hover:text-white transition-all text-brand-gold futuristic-glow">
                    Imperial Fitting
                  </button>
                  <button className="px-8 border border-brand-gold/30 rounded-full hover:bg-brand-rose hover:border-brand-rose hover:text-white transition-all text-brand-dark backdrop-blur-xl futuristic-glow group">
                    <Heart size={20} strokeWidth={1.5} className="group-hover:fill-current" />
                  </button>
                </div>
              </div>
              
              <div className="mt-12 flex items-center justify-between border-t border-brand-gold/10 pt-8">
                {['Free Shipping', 'Authenticity Guaranteed', '7 Days Return'].map((feat) => (
                  <div key={feat} className="flex flex-col items-center gap-2">
                    <CheckCircle2 size={12} className="text-brand-gold/40" />
                    <span className="text-[8px] text-brand-dark/40 uppercase tracking-[0.2em] font-bold">{feat}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default function Home() {
  return (
    <div className="relative overflow-x-hidden bg-mesh">
      <LocationBanner />
      <Hero />
      <motion.div 
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 1.5 }}
        className="relative z-10"
      >
        <CategoriesSection />
        <PromoBanner />
        <AboutSection />
      </motion.div>
    </div>
  );
}

