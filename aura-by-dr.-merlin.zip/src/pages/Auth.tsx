import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword,
  updateProfile,
  signInWithPopup,
  GoogleAuthProvider
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { useNavigate } from 'react-router-dom';
import { LogIn, UserPlus, ArrowRight, ShieldCheck, Mail, Lock, User, Globe } from 'lucide-react';

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError('');
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      
      // Check if user exists in firestore, if not create
      const userRef = doc(db, 'users', result.user.uid);
      const userSnap = await getDoc(userRef);
      
      if (!userSnap.exists()) {
        await setDoc(userRef, {
          uid: result.user.uid,
          email: result.user.email,
          name: result.user.displayName,
          role: 'customer',
          createdAt: serverTimestamp(),
          savedAddresses: []
        });
      }
      navigate('/');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (isLogin) {
        if (!email || !password) {
          setError('Email and password are required');
          return;
        }
        await signInWithEmailAndPassword(auth, email, password);
        navigate('/');
      } else {
        if (!name || !email || !password || !confirmPassword) {
          setError('All fields are required');
          return;
        }
        if (password.length < 6) {
          setError('Password must be at least 6 characters');
          return;
        }
        if (password !== confirmPassword) {
          setError('Passwords do not match');
          return;
        }
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        
        await updateProfile(user, { displayName: name });
        
        await setDoc(doc(db, 'users', user.uid), {
          uid: user.uid,
          email,
          name,
          role: 'customer',
          createdAt: serverTimestamp(),
          savedAddresses: []
        });
        
        navigate('/');
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex items-center justify-center p-6 bg-mesh selection:bg-brand-gold selection:text-white">
      {/* Dynamic Background Elements */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            animate={{ 
              scale: [1, 1.5, 1],
              opacity: [0.1, 0.2, 0.1],
              rotate: [0, 180, 360]
            }}
            transition={{ duration: 20 + i * 5, repeat: Infinity, ease: "linear" }}
            className="absolute bg-brand-gold/20 rounded-full blur-[120px]"
            style={{
              width: `${300 + i * 100}px`,
              height: `${300 + i * 100}px`,
              left: `${(i * 30) % 100}%`,
              top: `${(i * 20) % 100}%`,
            }}
          />
        ))}
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 50, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 1.5, ease: [0.19, 1, 0.22, 1] }}
        className="w-full max-w-5xl bg-white/5 backdrop-blur-[50px] shadow-[0_100px_150px_rgba(0,0,0,0.5)] rounded-[6rem] overflow-hidden flex flex-col md:flex-row border border-white/20 relative z-10 futuristic-glow"
      >
        {/* Left Side: Brand Essence */}
        <div className="md:w-5/12 bg-brand-dark p-16 text-white flex flex-col justify-between relative overflow-hidden border-r border-white/10">
          <div className="absolute inset-0 bg-mesh opacity-20" />
          <div className="relative z-10">
            <motion.div 
              initial={{ x: -30, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.5, duration: 1 }}
              className="mb-12"
            >
              <h2 className="text-5xl md:text-6xl font-serif italic mb-8 leading-tight tracking-tighter">
                Aura by <br/>
                <span className="text-brand-gold shimmer-text text-glow">Dr. Merlin</span> <br/>
                Studio
              </h2>
              <div className="h-px w-24 bg-brand-gold/50 mb-12" />
            </motion.div>
            
            <div className="space-y-8">
              {[
                { icon: ShieldCheck, text: 'Secure Authentication' },
                { icon: Globe, text: 'Global Shipping' },
                { icon: User, text: 'Personal Profile' },
              ].map((item, i) => (
                <motion.div 
                  key={i} 
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.7 + i * 0.1 }}
                  className="flex items-center gap-6 text-[10px] uppercase tracking-[0.5em] font-black text-white/50"
                >
                  <div className="w-10 h-10 rounded-2xl bg-white/5 flex items-center justify-center border border-white/10">
                    <item.icon size={16} className="text-brand-gold" />
                  </div>
                  {item.text}
                </motion.div>
              ))}
            </div>
          </div>
          <div className="relative z-10 mt-16 pt-10 border-t border-white/10">
            <p className="text-[10px] uppercase tracking-[0.6em] text-brand-gold font-black mb-4 italic">Artifacts of Grace</p>
            <p className="text-2xl font-serif italic text-white/90">Aura by Dr. Merlin</p>
          </div>
        </div>

        {/* Right Side: Form */}
        <div className="md:w-7/12 p-16 lg:p-24 relative overflow-hidden flex flex-col justify-center">
          <div className="mb-16">
            <div className="flex gap-10 mb-10 text-[10px] uppercase tracking-[0.5em] font-black">
              <button 
                onClick={() => setIsLogin(true)}
                className={`pb-4 border-b-2 transition-all group relative ${isLogin ? 'border-brand-gold text-brand-dark' : 'border-transparent text-brand-dark/20'}`}
              >
                Login
                {isLogin && <motion.div layoutId="authTab" className="absolute -bottom-[2px] left-0 w-full h-[2px] bg-brand-gold futuristic-glow-gold" />}
              </button>
              <button 
                onClick={() => setIsLogin(false)}
                className={`pb-4 border-b-2 transition-all group relative ${!isLogin ? 'border-brand-gold text-brand-dark' : 'border-transparent text-brand-dark/20'}`}
              >
                Sign Up
                {!isLogin && <motion.div layoutId="authTab" className="absolute -bottom-[2px] left-0 w-full h-[2px] bg-brand-gold futuristic-glow-gold" />}
              </button>
            </div>
            <h3 className="text-6xl font-serif italic text-brand-dark mb-6 tracking-tighter">
              {isLogin ? 'Login' : 'Create Account'}
            </h3>
            <p className="text-brand-dark/30 text-xs italic tracking-widest leading-relaxed max-w-sm">
              {isLogin ? 'Sign in to access your account.' : 'Join us for a tailored experience.'}
            </p>
          </div>

          <AnimatePresence mode="wait">
            <motion.form 
              key={isLogin ? 'login' : 'signup'}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.6, ease: [0.19, 1, 0.22, 1] }}
              onSubmit={handleSubmit} 
              className="space-y-8"
            >
              {error && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-6 bg-brand-rose/5 text-brand-rose text-[10px] uppercase font-black tracking-[0.3em] rounded-3xl border border-brand-rose/10 flex items-center gap-4"
                >
                  <ShieldCheck size={16} /> {error}
                </motion.div>
              )}

              <div className="space-y-6">
                {!isLogin && (
                  <>
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="relative group"
                    >
                      <User size={20} className="absolute left-8 top-1/2 -translate-y-1/2 text-brand-gold transition-all group-focus-within:scale-110" />
                      <input 
                        type="text" 
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full pl-16 pr-10 py-7 rounded-[3rem] bg-white/10 border border-brand-gold/10 focus:border-brand-gold focus:outline-none text-lg transition-all shadow-inner text-brand-dark italic font-serif"
                        placeholder="Full Name"
                      />
                    </motion.div>
                  </>
                )}
                
                <div className="relative group">
                  <Mail size={20} className="absolute left-8 top-1/2 -translate-y-1/2 text-brand-gold transition-all group-focus-within:scale-110" />
                  <input 
                    type="email" 
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-16 pr-10 py-7 rounded-[3rem] bg-white/10 border border-brand-gold/10 focus:border-brand-gold focus:outline-none text-lg transition-all shadow-inner text-brand-dark italic font-serif"
                    placeholder="Email Address"
                  />
                </div>

                <div className="relative group">
                  <Lock size={20} className="absolute left-8 top-1/2 -translate-y-1/2 text-brand-gold transition-all group-focus-within:scale-110" />
                  <input 
                    type="password" 
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-16 pr-10 py-7 rounded-[3rem] bg-white/10 border border-brand-gold/10 focus:border-brand-gold focus:outline-none text-lg transition-all shadow-inner text-brand-dark italic font-serif"
                    placeholder="Password"
                  />
                </div>

                {!isLogin && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="relative group"
                  >
                    <Lock size={20} className="absolute left-8 top-1/2 -translate-y-1/2 text-brand-gold transition-all group-focus-within:scale-110" />
                    <input 
                      type="password" 
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full pl-16 pr-10 py-7 rounded-[3rem] bg-white/10 border border-brand-gold/10 focus:border-brand-gold focus:outline-none text-lg transition-all shadow-inner text-brand-dark italic font-serif"
                      placeholder="Confirm Password"
                    />
                  </motion.div>
                )}
              </div>

              {isLogin && (
                <div className="flex justify-end">
                  <button type="button" className="text-[10px] uppercase tracking-widest font-black text-brand-gold hover:text-brand-dark transition-all italic">
                    Forgot Password?
                  </button>
                </div>
              )}

              <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit" 
                disabled={loading}
                className="w-full gold-shimmer text-white py-8 rounded-full text-[12px] uppercase tracking-[0.5em] font-black shadow-2xl transition-all flex items-center justify-center gap-4 disabled:opacity-50 futuristic-glow"
              >
                {loading ? 'Processing...' : (isLogin ? 'Login' : 'Create Account')}
                <ArrowRight size={20} />
              </motion.button>

              <div className="text-center pt-4">
                <button 
                  type="button"
                  onClick={() => setIsLogin(!isLogin)}
                  className="text-[10px] uppercase tracking-widest font-black text-brand-dark/40 hover:text-brand-gold transition-all italic"
                >
                  {isLogin ? "Don't have an account? Sign up" : "Already have an account? Login"}
                </button>
              </div>
            </motion.form>
          </AnimatePresence>

          <div className="mt-16">
            <div className="relative flex items-center justify-center mb-10">
              <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-brand-gold/10"></div></div>
              <span className="relative z-10 px-8 bg-brand-cream-light text-[10px] uppercase font-black text-brand-dark/20 tracking-[0.6em]">Or login with</span>
            </div>

            <motion.button 
              whileHover={{ scale: 1.02, backgroundColor: 'rgba(0,0,0,0.05)' }}
              whileTap={{ scale: 0.98 }}
              onClick={handleGoogleLogin}
              disabled={loading}
              className="w-full bg-transparent border border-brand-gold/20 text-brand-dark py-6 rounded-full text-[10px] uppercase tracking-[0.4em] font-black transition-all flex items-center justify-center gap-6 shadow-sm hover:border-brand-gold"
            >
              <svg className="w-6 h-6" viewBox="0 0 24 24">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
              </svg>
              <span>Continue with Google</span>
            </motion.button>
          </div>
          
          <p className="mt-16 text-center text-[10px] text-brand-dark/20 uppercase tracking-[0.4em] font-black italic">
            Your privacy is our priority.
          </p>
        </div>
      </motion.div>
    </div>
  );
}
