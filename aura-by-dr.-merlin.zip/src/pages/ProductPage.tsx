import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShoppingBag, 
  Heart, 
  Share2, 
  ArrowLeft, 
  Plus, 
  Minus, 
  Star,
  CheckCircle2,
  ShieldCheck,
  Globe,
  Clock,
  ArrowRight
} from 'lucide-react';
import { PRODUCTS, type Product } from '../constants';
import { useShop } from '../context/ShopContext';

export default function ProductPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { formatPrice, addToCart } = useShop();
  const [product, setProduct] = useState<Product | null>(null);
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState('M');
  const [justAdded, setJustAdded] = useState(false);

  useEffect(() => {
    const p = PRODUCTS.find(item => item.id === id);
    if (p) {
      setProduct(p);
      setSelectedImage(p.image);
    } else {
      navigate('/collections');
    }
  }, [id, navigate]);

  if (!product) return null;

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 2000);
  };

  const images = [product.image, product.image2 || product.image];

  return (
    <div className="min-h-screen bg-mesh pt-48 pb-32 px-6 relative overflow-hidden selection:bg-brand-gold selection:text-white sm:cursor-none">
      {/* Background Ambience */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-0 right-0 w-[1000px] h-[1000px] bg-brand-gold/5 rounded-full blur-[200px] -mr-[30%] -mt-[20%]" />
        <div className="absolute bottom-0 left-0 w-[800px] h-[800px] bg-brand-dark/5 rounded-full blur-[200px] -ml-[20%] -mb-[20%]" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Navigation Breadcrumb */}
        <motion.button 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={() => navigate('/collections')}
          className="flex items-center gap-4 text-[10px] uppercase tracking-[0.5em] font-black text-brand-dark/40 hover:text-brand-gold mb-16 group transition-all"
        >
          <ArrowLeft size={16} className="group-hover:-translate-x-2 transition-transform" />
          Retrace to Collections
        </motion.button>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-20 xl:gap-32">
          {/* Left: Gallery */}
          <div className="lg:col-span-7 space-y-10 order-2 lg:order-1">
            <div className="grid grid-cols-6 gap-8 items-start">
              {/* Thumbnails */}
              <div className="col-span-1 space-y-6">
                {images.map((img, idx) => (
                  <motion.button
                    key={idx}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedImage(img)}
                    className={`w-full aspect-[3/4] rounded-2xl overflow-hidden border-2 transition-all ${selectedImage === img ? 'border-brand-gold shadow-[0_0_20px_#C89B3C]' : 'border-transparent opacity-40 hover:opacity-100'}`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </motion.button>
                ))}
              </div>

              {/* Main Image Display */}
              <div className="col-span-5">
                <motion.div 
                  layoutId={`product-img-${product.id}`}
                  className="aspect-[3/4] rounded-[4rem] overflow-hidden bg-white shadow-2xl relative border border-white/20 group futuristic-glow"
                >
                  <AnimatePresence mode="wait">
                    <motion.img 
                      key={selectedImage}
                      src={selectedImage}
                      initial={{ opacity: 0, scale: 1.1 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 1.1 }}
                      transition={{ duration: 0.8, ease: [0.19, 1, 0.22, 1] }}
                      className="w-full h-full object-cover"
                    />
                  </AnimatePresence>
                  <div className="absolute top-10 left-10 w-12 h-px bg-brand-gold" />
                  <div className="absolute bottom-10 right-10 w-12 h-px bg-brand-gold" />
                </motion.div>
                
                {/* Image Counter */}
                <div className="flex justify-center mt-10 gap-3">
                  {images.map((_, i) => (
                    <div key={i} className={`h-1 rounded-full transition-all duration-500 ${selectedImage === images[i] ? 'w-12 bg-brand-gold' : 'w-4 bg-brand-gold/20'}`} />
                  ))}
                </div>
              </div>
            </div>

            {/* Additional Features / Story */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mt-20">
               <motion.div 
                 initial={{ opacity: 0, y: 20 }}
                 whileInView={{ opacity: 1, y: 0 }}
                 viewport={{ once: true }}
                 className="p-10 bg-white/5 backdrop-blur-3xl rounded-[3rem] border border-white/20 shadow-2xl futuristic-glow group overflow-hidden"
               >
                 <div className="absolute inset-0 bg-mesh opacity-10" />
                 <ShieldCheck className="text-brand-gold mb-6 group-hover:scale-110 transition-transform" size={28} />
                 <h4 className="text-[10px] uppercase tracking-[0.5em] font-black text-brand-dark italic mb-4">Celestial Authenticity</h4>
                 <p className="text-[10px] uppercase font-black tracking-[0.2em] text-brand-dark/40 leading-relaxed italic">Every fiber in this artifact is verified through the Merlin Heritage Protocol, ensuring the highest echelon of traditional craftsmanship.</p>
               </motion.div>
               <motion.div 
                 initial={{ opacity: 0, y: 20 }}
                 whileInView={{ opacity: 1, y: 0 }}
                 viewport={{ once: true }}
                 transition={{ delay: 0.1 }}
                 className="p-10 bg-white/5 backdrop-blur-3xl rounded-[3rem] border border-white/20 shadow-2xl futuristic-glow group overflow-hidden"
               >
                 <div className="absolute inset-0 bg-mesh opacity-10" />
                 <Globe className="text-brand-gold mb-6 group-hover:scale-110 transition-transform" size={28} />
                 <h4 className="text-[10px] uppercase tracking-[0.5em] font-black text-brand-dark italic mb-4">Universal Dispatch</h4>
                 <p className="text-[10px] uppercase font-black tracking-[0.2em] text-brand-dark/40 leading-relaxed italic">Materials sourced from sacred groves and territories, orchestrated and delivered across the global matrix within 5-7 solar cycles.</p>
               </motion.div>
            </div>
          </div>

          {/* Right: Details */}
          <div className="lg:col-span-5 order-1 lg:order-2">
            <header className="mb-12">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-4 mb-6"
              >
                <div className="h-px w-8 bg-brand-gold" />
                <span className="text-brand-gold text-[10px] uppercase tracking-[0.6em] font-black italic">{product.category} Artifact</span>
              </motion.div>
              <motion.h1 
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
                className="text-6xl md:text-8xl font-serif italic text-brand-dark leading-tight tracking-tighter mb-8"
              >
                {product.name}
              </motion.h1>
              
              <div className="flex items-center gap-8 mb-10">
                <p className="text-4xl md:text-5xl font-serif text-brand-dark italic tracking-tighter shimmer-text">
                  {formatPrice(product.price)}
                </p>
                <div className="flex items-center gap-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={14} className={i < 4 ? 'text-brand-gold' : 'text-brand-gold/20'} fill={i < 4 ? 'currentColor' : 'none'} />
                  ))}
                  <span className="text-[10px] uppercase font-black tracking-widest text-brand-dark/30 ml-2">(4.9 Aura Rating)</span>
                </div>
              </div>
              
              <p className="text-xs text-brand-dark/50 leading-relaxed tracking-widest italic max-w-lg mb-12">
                {product.description || 'A masterpiece of ethereal design, where traditional inheritance meets the futuristic matrix of luxury fashion.'}
              </p>
            </header>

            <div className="space-y-16">
              {/* Size Selection */}
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h4 className="text-[10px] uppercase tracking-[0.5em] font-black text-brand-dark italic">Sizing Matrix</h4>
                  <button className="text-[9px] uppercase tracking-widest font-black text-brand-gold border-b border-brand-gold/10 pb-1">Guide to Geometry</button>
                </div>
                <div className="flex gap-4">
                  {['S', 'M', 'L', 'XL'].map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`w-16 h-16 rounded-2xl flex items-center justify-center text-[10px] font-black transition-all relative overflow-hidden ${
                        selectedSize === size 
                          ? 'bg-brand-dark text-brand-gold futuristic-glow' 
                          : 'bg-white/10 border border-white/20 text-brand-dark/30 hover:border-brand-gold/40 hover:text-brand-dark'
                      }`}
                    >
                      {size}
                      {selectedSize === size && (
                        <motion.div layoutId="sizeActive" className="absolute bottom-1 w-1 h-1 bg-brand-gold rounded-full" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quantity */}
              <div>
                <h4 className="text-[10px] uppercase tracking-[0.5em] font-black text-brand-dark mb-6 italic">Batch Manifest</h4>
                <div className="flex items-center gap-8">
                  <div className="flex items-center bg-white/10 backdrop-blur-3xl rounded-full border border-white/20 p-2 h-16 shadow-inner">
                    <button 
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="w-12 h-12 rounded-full flex items-center justify-center text-brand-dark hover:bg-brand-dark hover:text-white transition-all"
                    >
                      <Minus size={16} />
                    </button>
                    <span className="w-16 text-center font-serif text-xl italic text-brand-dark">{quantity}</span>
                    <button 
                      onClick={() => setQuantity(quantity + 1)}
                      className="w-12 h-12 rounded-full flex items-center justify-center text-brand-dark hover:bg-brand-dark hover:text-white transition-all"
                    >
                      <Plus size={16} />
                    </button>
                  </div>
                  <motion.button 
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="w-16 h-16 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-brand-dark hover:text-brand-rose hover:border-brand-rose transition-all shadow-xl"
                  >
                    <Heart size={20} />
                  </motion.button>
                  <motion.button 
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="w-16 h-16 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-brand-dark hover:text-brand-gold hover:border-brand-gold transition-all shadow-xl"
                  >
                    <Share2 size={20} />
                  </motion.button>
                </div>
              </div>

              {/* Main Actions */}
              <div className="pt-10 space-y-6">
                <motion.button 
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleAddToCart}
                  className={`w-full py-8 rounded-full text-[12px] uppercase tracking-[0.6em] font-black shadow-[0_30px_60px_rgba(200,155,60,0.3)] transition-all flex items-center justify-center gap-6 futuristic-glow relative overflow-hidden group ${justAdded ? 'bg-brand-green/20 text-brand-green border-brand-green/30' : 'gold-shimmer text-white'}`}
                >
                  <AnimatePresence mode="wait">
                    {justAdded ? (
                      <motion.div 
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: -20, opacity: 0 }}
                        key="added"
                        className="flex items-center gap-4"
                      >
                        Materialized in Bag <CheckCircle2 size={24} />
                      </motion.div>
                    ) : (
                      <motion.div 
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: -20, opacity: 0 }}
                        key="add"
                        className="flex items-center gap-4"
                      >
                        Acquire Artifact <ShoppingBag size={24} className="group-hover:rotate-12 transition-transform" />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.button>

                <p className="flex items-center justify-center gap-4 text-[10px] uppercase font-black tracking-[0.4em] text-brand-dark/20 italic">
                  <ShieldCheck size={14} className="text-brand-gold/30" /> Secure Encryption Active
                </p>
              </div>

              {/* Product Specifications - Accordion Style */}
              <div className="border-t border-brand-gold/10 pt-12 space-y-10">
                <div className="group cursor-pointer">
                  <div className="flex justify-between items-center mb-6">
                    <h4 className="text-[10px] uppercase tracking-[0.5em] font-black text-brand-dark group-hover:text-brand-gold transition-colors">Composition & Origin</h4>
                    <Plus size={16} className="text-brand-gold transition-transform group-hover:rotate-90" />
                  </div>
                  <div className="h-0 group-hover:h-auto overflow-hidden transition-all duration-500">
                    <p className="text-[10px] uppercase font-bold tracking-[0.2em] text-brand-dark/40 italic leading-relaxed">
                      Hand-woven silk from the sacred looms of Varanasi, detailed with 24k gold zari threads and celestial embroidery patterns.
                    </p>
                  </div>
                </div>
                <div className="group cursor-pointer">
                  <div className="flex justify-between items-center mb-6">
                    <h4 className="text-[10px] uppercase tracking-[0.5em] font-black text-brand-dark group-hover:text-brand-gold transition-colors">Dispatch Ritual</h4>
                    <Plus size={16} className="text-brand-gold transition-transform group-hover:rotate-90" />
                  </div>
                  <div className="h-0 group-hover:h-auto overflow-hidden transition-all duration-500">
                    <p className="text-[10px] uppercase font-bold tracking-[0.2em] text-brand-dark/40 italic leading-relaxed">
                      Free global translocation via Imperial Couriers. Every artifact arrives in a curated glass-matrix preservation box.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Suggestive Section */}
        <div className="mt-48 pt-32 border-t border-brand-gold/10">
          <div className="flex items-end justify-between mb-20">
            <div>
              <span className="text-brand-gold text-[10px] uppercase tracking-[0.8em] font-black block mb-4 italic">Ethereal Pairing</span>
              <h3 className="text-5xl md:text-7xl font-serif italic text-brand-dark tracking-tighter">Harmonies</h3>
            </div>
            <button 
              onClick={() => navigate('/collections')}
              className="text-[10px] uppercase tracking-[0.4em] font-black text-brand-dark hover:text-brand-gold transition-all flex items-center gap-4 group pb-2"
            >
              Explore Nexus <ArrowRight size={16} className="group-hover:translate-x-2 transition-transform" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
            {PRODUCTS.slice(0, 4).map((p, i) => (
              <motion.div 
                key={p.id}
                whileHover={{ y: -15 }}
                onClick={() => navigate(`/product/${p.id}`)}
                className="group cursor-pointer"
              >
                <div className="aspect-[3/4] rounded-[3rem] overflow-hidden bg-white mb-8 relative border border-transparent group-hover:border-brand-gold/20 shadow-xl transition-all futuristic-glow">
                  <img src={p.image} alt="" className="w-full h-full object-cover grayscale-[0.3] group-hover:grayscale-0 transition-all duration-700 hover:scale-110" />
                </div>
                <h4 className="text-lg font-serif italic text-brand-dark group-hover:text-brand-gold transition-all">{p.name}</h4>
                <p className="text-[10px] uppercase tracking-widest font-black text-brand-dark/30 mt-2">{formatPrice(p.price)}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
