import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShoppingBag, 
  ChevronRight, 
  CreditCard, 
  MapPin, 
  Truck, 
  CheckCircle2,
  ArrowLeft,
  User as UserIcon,
  ShieldCheck,
  Package,
  Wallet
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useShop } from '../context/ShopContext';
import { auth, db } from '../lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

type CheckoutStep = 'identification' | 'shipping' | 'review' | 'payment';

export default function Checkout() {
  const { cart, cartTotal, formatPrice, clearCart } = useShop();
  const [step, setStep] = useState<CheckoutStep>('identification');
  const [user, setUser] = useState(auth.currentUser);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // Form States
  const [shippingInfo, setShippingInfo] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    zip: '',
    country: 'India'
  });

  const [paymentMethod, setPaymentMethod] = useState<'card' | 'cod'>('card');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (u) {
        setShippingInfo(prev => ({ ...prev, email: u.email || '', name: u.displayName || '' }));
        if (step === 'identification') setStep('shipping');
      }
    });
    return () => unsubscribe();
  }, [step]);

  // If cart is empty, redirect to home
  useEffect(() => {
    if (cart.length === 0) {
      const timer = setTimeout(() => navigate('/'), 2000);
      return () => clearTimeout(timer);
    }
  }, [cart, navigate]);

  if (cart.length === 0) {
    return (
      <div className="pt-40 pb-20 px-6 min-h-screen flex flex-col items-center justify-center text-center bg-mesh">
        <div className="w-24 h-24 bg-white/10 backdrop-blur-3xl rounded-full flex items-center justify-center mx-auto mb-8 text-brand-gold/30 futuristic-glow">
          <Package size={48} />
        </div>
        <h2 className="text-5xl font-serif mb-6 italic text-brand-dark leading-tight">Your bag is light</h2>
        <p className="text-brand-dark/50 mb-10 leading-relaxed italic text-lg font-serif">
          Redirecting you to the studio for curation...
        </p>
      </div>
    );
  }

  const handlePlaceOrder = async () => {
    setLoading(true);
    try {
      const orderData = {
        userId: user?.uid || 'guest',
        items: cart,
        shipping: shippingInfo,
        payment: {
          method: paymentMethod,
          status: paymentMethod === 'cod' ? 'pending' : 'paid'
        },
        total: cartTotal,
        status: 'processing',
        createdAt: serverTimestamp()
      };

      await addDoc(collection(db, 'orders'), orderData);
      clearCart();
      navigate('/order-success');
    } catch (error) {
      console.error("Order Error:", error);
    } finally {
      setLoading(false);
    }
  };

  const steps: { name: CheckoutStep; label: string; icon: any }[] = [
    { name: 'identification', label: 'Identity', icon: UserIcon },
    { name: 'shipping', label: 'Aura Reach', icon: MapPin },
    { name: 'review', label: 'Curation', icon: Package },
    { name: 'payment', label: 'Exchange', icon: Wallet },
  ];

  const currentStepIdx = steps.findIndex(s => s.name === step);

  return (
    <div className="pt-40 pb-20 px-6 max-w-7xl mx-auto min-h-screen bg-mesh">
      <header className="text-center mb-20">
        <h1 className="text-5xl md:text-8xl font-serif italic mb-12 text-brand-dark leading-tight">Complete Your Journey</h1>
        
        {/* Progress Bar */}
        <div className="max-w-4xl mx-auto relative px-4">
          <div className="absolute top-8 left-12 right-12 h-px bg-brand-gold/10 z-0" />
          <div className="flex justify-between items-center relative z-10">
            {steps.map((s, idx) => (
              <div key={s.name} className="flex flex-col items-center gap-4">
                <div 
                  className={`w-16 h-16 rounded-full border flex items-center justify-center transition-all duration-[1s] ${
                    currentStepIdx >= idx 
                      ? 'bg-brand-gold border-brand-gold text-white shadow-[0_20px_40px_rgba(200,155,60,0.3)] scale-110' 
                      : 'bg-white/5 backdrop-blur-2xl border-white/20 text-brand-dark/20'
                  }`}
                >
                  <s.icon size={22} className={currentStepIdx >= idx ? 'animate-pulse' : ''} />
                </div>
                <span className={`text-[10px] uppercase tracking-[0.5em] font-black ${
                  currentStepIdx >= idx ? 'text-brand-dark' : 'text-brand-dark/20'
                }`}>
                  {s.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </header>

      <div className="flex flex-col lg:flex-row gap-24">
        {/* Left Side: Form Flow */}
        <div className="flex-1 min-h-[600px] relative">
          <AnimatePresence mode="wait">
            {step === 'identification' && (
              <motion.div 
                key="id"
                initial={{ opacity: 0, x: -50, rotateY: -10 }}
                animate={{ opacity: 1, x: 0, rotateY: 0 }}
                exit={{ opacity: 0, x: 50, rotateY: 10 }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                className="bg-white/10 backdrop-blur-3xl p-16 rounded-[5rem] shadow-2xl border border-white/20 text-center futuristic-glow"
              >
                <div className="w-24 h-24 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-10 text-brand-gold futuristic-glow">
                  <UserIcon size={40} />
                </div>
                <h3 className="text-5xl font-serif italic mb-8">Hello, Beautiful</h3>
                <p className="text-brand-dark/50 mb-12 leading-relaxed max-w-sm mx-auto text-xl italic font-serif">
                  "Log in for a tailored ethereal experience, or continue as our guest."
                </p>
                <div className="space-y-6">
                  <motion.button 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => navigate('/auth')}
                    className="w-full bg-brand-dark text-white py-7 rounded-full text-[10px] uppercase tracking-[0.4em] font-black shadow-2xl futuristic-glow"
                  >
                    Login to My Aura Account
                  </motion.button>
                  <motion.button 
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setStep('shipping')}
                    className="w-full bg-white/5 border border-brand-gold/30 text-brand-gold py-7 rounded-full text-[10px] uppercase tracking-[0.4em] font-black hover:bg-brand-gold hover:text-white transition-all shadow-xl backdrop-blur-xl"
                  >
                    Continue as Guest
                  </motion.button>
                </div>
              </motion.div>
            )}

            {step === 'shipping' && (
              <motion.div 
                key="shipping"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.1 }}
                className="space-y-12"
              >
                <div className="flex items-center gap-6">
                  <button onClick={() => setStep(user ? 'shipping' : 'identification')} className="p-4 bg-white/10 rounded-full text-brand-gold hover:bg-brand-dark hover:text-white transition-all"><ArrowLeft size={24} /></button>
                  <h3 className="text-4xl font-serif italic">Shipping Destinations</h3>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  <div className="md:col-span-2 group">
                    <label className="block text-[10px] uppercase font-black tracking-[0.4em] text-brand-gold mb-4 ml-6 transition-all group-focus-within:tracking-[0.6em]">Full Artifact Name</label>
                    <input 
                      type="text" 
                      value={shippingInfo.name}
                      onChange={(e) => setShippingInfo({...shippingInfo, name: e.target.value})}
                      className="w-full px-10 py-6 rounded-[2.5rem] bg-white/10 backdrop-blur-3xl border border-white/20 focus:border-brand-gold focus:outline-none text-lg transition-all text-brand-dark shadow-xl"
                      placeholder="Recipient's Title"
                    />
                  </div>
                  <div className="md:col-span-2 group">
                    <label className="block text-[10px] uppercase font-black tracking-[0.4em] text-brand-gold mb-4 ml-6">Digital Address (Email)</label>
                    <input 
                      type="email" 
                      value={shippingInfo.email}
                      onChange={(e) => setShippingInfo({...shippingInfo, email: e.target.value})}
                      className="w-full px-10 py-6 rounded-[2.5rem] bg-white/10 backdrop-blur-3xl border border-white/20 focus:border-brand-gold focus:outline-none text-lg transition-all text-brand-dark shadow-xl"
                      placeholder="cipher@aura.studio"
                    />
                  </div>
                  <div className="md:col-span-2 group">
                    <label className="block text-[10px] uppercase font-black tracking-[0.4em] text-brand-gold mb-4 ml-6">Ethereal Coordinates</label>
                    <textarea 
                      rows={3}
                      value={shippingInfo.address}
                      onChange={(e) => setShippingInfo({...shippingInfo, address: e.target.value})}
                      className="w-full px-10 py-6 rounded-[2.5rem] bg-white/10 backdrop-blur-3xl border border-white/20 focus:border-brand-gold focus:outline-none text-lg transition-all text-brand-dark shadow-xl resize-none"
                      placeholder="Palace, Garden, Street"
                    />
                  </div>
                  <div className="group">
                    <label className="block text-[10px] uppercase font-black tracking-[0.4em] text-brand-gold mb-4 ml-6">Imperial City</label>
                    <input 
                      type="text" 
                      value={shippingInfo.city}
                      onChange={(e) => setShippingInfo({...shippingInfo, city: e.target.value})}
                      className="w-full px-10 py-6 rounded-[2.5rem] bg-white/10 backdrop-blur-3xl border border-white/20 focus:border-brand-gold focus:outline-none text-lg transition-all text-brand-dark shadow-xl"
                      placeholder="New Delhi"
                    />
                  </div>
                  <div className="group">
                    <label className="block text-[10px] uppercase font-black tracking-[0.4em] text-brand-gold mb-4 ml-6">Zip Cipher</label>
                    <input 
                      type="text" 
                      value={shippingInfo.zip}
                      onChange={(e) => setShippingInfo({...shippingInfo, zip: e.target.value})}
                      className="w-full px-10 py-6 rounded-[2.5rem] bg-white/10 backdrop-blur-3xl border border-white/20 focus:border-brand-gold focus:outline-none text-lg transition-all text-brand-dark shadow-xl"
                      placeholder="110017"
                    />
                  </div>
                </div>

                <motion.button 
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setStep('review')}
                  disabled={!shippingInfo.name || !shippingInfo.address}
                  className="w-full gold-shimmer text-white py-8 rounded-full text-[12px] uppercase tracking-[0.5em] font-black shadow-2xl disabled:opacity-50 group flex items-center justify-center gap-4 futuristic-glow"
                >
                  Review Curation <ChevronRight size={18} className="group-hover:translate-x-3 transition-transform" />
                </motion.button>
              </motion.div>
            )}

            {step === 'review' && (
              <motion.div 
                key="review"
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -50 }}
                className="space-y-12"
              >
                <div className="flex items-center gap-6">
                  <button onClick={() => setStep('shipping')} className="p-4 bg-white/10 rounded-full text-brand-gold hover:bg-brand-dark hover:text-white transition-all"><ArrowLeft size={24} /></button>
                  <h3 className="text-4xl font-serif italic">Curated Collection Review</h3>
                </div>

                <div className="grid grid-cols-1 gap-8">
                  {cart.map((item) => (
                    <div key={item.id} className="bg-white/5 backdrop-blur-3xl p-8 rounded-[4rem] shadow-xl border border-white/10 flex gap-8 group futuristic-glow">
                      <div className="w-32 aspect-[3/4] rounded-[2rem] overflow-hidden shadow-2xl flex-shrink-0 border border-white/10">
                        <img src={item.image} className="w-full h-full object-cover group-hover:scale-110 transition-all duration-[1s]" />
                      </div>
                      <div className="flex-1 py-4 flex flex-col justify-between">
                        <div>
                          <h4 className="text-3xl font-serif italic group-hover:text-brand-gold transition-colors">{item.name}</h4>
                          <p className="text-[10px] text-brand-dark/40 uppercase tracking-[0.5em] font-black mt-2">{item.category} &bull; Vol: {item.quantity}</p>
                        </div>
                        <p className="text-2xl font-black text-brand-dark tracking-tighter">{formatPrice(item.price, item)}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-white/5 backdrop-blur-3xl p-10 rounded-[3.5rem] border border-brand-gold/20 shadow-2xl relative overflow-hidden group">
                  <div className="absolute inset-0 bg-brand-gold/5 -translate-x-full group-hover:translate-x-0 transition-transform duration-[1.5s]" />
                  <div className="relative z-10">
                    <div className="flex justify-between items-start mb-6">
                      <h4 className="text-[10px] uppercase tracking-[0.65em] font-black text-brand-gold">Manifest Destination</h4>
                      <button onClick={() => setStep('shipping')} className="text-[8px] uppercase font-black text-brand-dark/40 border-b border-brand-dark/20 hover:text-brand-dark transition-colors tracking-widest">Re-Cipher</button>
                    </div>
                    <p className="text-xl font-serif text-brand-dark flex flex-col gap-2">
                      <span className="font-black italic underline decoration-brand-gold/30">{shippingInfo.name}</span>
                      <span className="text-brand-dark/50 text-lg">{shippingInfo.address}, {shippingInfo.city}, {shippingInfo.zip}</span>
                    </p>
                  </div>
                </div>

                <motion.button 
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setStep('payment')}
                  className="w-full gold-shimmer text-white py-8 rounded-full text-[12px] uppercase tracking-[0.5em] font-black shadow-2xl flex items-center justify-center gap-4 futuristic-glow"
                >
                  Confirm Aura Exchange <Wallet size={20} />
                </motion.button>
              </motion.div>
            )}

            {step === 'payment' && (
              <motion.div 
                key="payment"
                initial={{ opacity: 0, scale: 1.1, rotateX: 10 }}
                animate={{ opacity: 1, scale: 1, rotateX: 0 }}
                exit={{ opacity: 0, scale: 0.9, rotateX: -10 }}
                className="space-y-12"
              >
                <div className="flex items-center gap-6">
                  <button onClick={() => setStep('review')} className="p-4 bg-white/10 rounded-full text-brand-gold hover:bg-brand-dark hover:text-white transition-all"><ArrowLeft size={24} /></button>
                  <h3 className="text-4xl font-serif italic">Secure Ethereal Exchange</h3>
                </div>

                <div className="grid grid-cols-1 gap-8">
                  {[
                    { id: 'card', label: 'Celestial Matrix (Card)', icon: CreditCard, desc: 'Hyper-secure global encryption' },
                    { id: 'cod', label: 'Legacy Token (COD)', icon: Truck, desc: 'Classic Physical Exchange' },
                  ].map((m) => (
                    <button
                      key={m.id}
                      onClick={() => setPaymentMethod(m.id as any)}
                      className={`w-full text-left p-10 rounded-[4rem] border transition-all flex items-center gap-8 relative overflow-hidden group ${
                        paymentMethod === m.id 
                          ? 'border-brand-gold bg-brand-gold/5 shadow-[0_30px_60px_rgba(0,0,0,0.15)] scale-[1.02]' 
                          : 'border-white/20 bg-white/5 opacity-60 hover:opacity-100 backdrop-blur-xl'
                      }`}
                    >
                      <div className={`w-20 h-20 rounded-full flex items-center justify-center transition-colors ${
                        paymentMethod === m.id ? 'bg-brand-gold text-white shadow-xl' : 'bg-white/10 text-brand-gold'
                      }`}>
                        <m.icon size={28} />
                      </div>
                      <div className="flex-1">
                        <p className="font-black text-lg uppercase tracking-[0.4em]">{m.label}</p>
                        <p className="text-[10px] text-brand-dark/40 mt-2 uppercase font-black italic tracking-widest">{m.desc}</p>
                      </div>
                      <div className={`w-8 h-8 rounded-full border flex items-center justify-center transition-all ${
                        paymentMethod === m.id ? 'border-brand-gold border-2' : 'border-white/20'
                      }`}>
                        <AnimatePresence>
                          {paymentMethod === m.id && (
                            <motion.div 
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              className="w-4 h-4 bg-brand-gold rounded-full" 
                            />
                          )}
                        </AnimatePresence>
                      </div>
                    </button>
                  ))}
                </div>

                {paymentMethod === 'card' && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-white/5 backdrop-blur-3xl p-12 rounded-[5rem] border border-white/20 shadow-2xl space-y-10 futuristic-glow"
                  >
                    <div className="group">
                      <label className="block text-[10px] uppercase font-black tracking-[0.4em] text-brand-gold mb-4 ml-6">Empress Name on Matrix</label>
                      <input type="text" className="w-full px-10 py-6 rounded-[2rem] border border-white/10 focus:border-brand-gold bg-white/5 text-lg text-brand-dark transition-all placeholder:italic" placeholder="DR. MERLIN" />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="group">
                        <label className="block text-[10px] uppercase font-black tracking-[0.4em] text-brand-gold mb-4 ml-6">Temporal Expiry</label>
                        <input type="text" className="w-full px-10 py-6 rounded-[2rem] border border-white/10 focus:border-brand-gold bg-white/5 text-lg text-brand-dark transition-all placeholder:italic" placeholder="MM/YY" />
                      </div>
                      <div className="group">
                        <label className="block text-[10px] uppercase font-black tracking-[0.4em] text-brand-gold mb-4 ml-6">Security Cipher (CVC)</label>
                        <input type="text" className="w-full px-10 py-6 rounded-[2rem] border border-white/10 focus:border-brand-gold bg-white/5 text-lg text-brand-dark transition-all placeholder:italic" placeholder="•••" />
                      </div>
                    </div>
                  </motion.div>
                )}

                <motion.button 
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handlePlaceOrder}
                  disabled={loading}
                  className="w-full gold-shimmer text-white py-10 rounded-full text-[14px] uppercase tracking-[0.6em] font-black shadow-[0_40px_80px_rgba(200,155,60,0.4)] transition-all flex items-center justify-center gap-6 disabled:opacity-50 futuristic-glow"
                >
                  {loading ? (
                    <motion.div 
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                      className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full"
                    />
                  ) : (
                    <>Commit Exchange for {formatPrice(cartTotal)} <ShieldCheck size={24} /></>
                  )}
                </motion.button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right Side: Summary Card */}
        <div className="lg:w-[480px]">
          <div className="bg-white/10 backdrop-blur-3xl p-16 rounded-[6rem] shadow-[0_50px_100px_rgba(0,0,0,0.2)] border border-white/20 sticky top-40 futuristic-glow">
            <h4 className="text-3xl font-serif italic mb-12 text-brand-dark text-center border-b border-brand-gold/10 pb-6">Aura Invoice Artifact</h4>
            
            <div className="space-y-8 mb-12">
              <div className="flex justify-between items-center text-[10px]">
                <span className="text-brand-dark/40 uppercase tracking-[0.5em] font-black">Celestial Mass</span>
                <span className="font-black text-brand-dark tracking-widest">{cart.reduce((a, b) => a + b.quantity, 0)} Units</span>
              </div>
              <div className="flex justify-between items-center text-[10px]">
                <span className="text-brand-dark/40 uppercase tracking-[0.5em] font-black">Empirical Volume</span>
                <span className="font-black text-brand-dark tracking-widest">{formatPrice(cartTotal)}</span>
              </div>
              <div className="flex justify-between items-center text-[10px]">
                <span className="text-brand-dark/40 uppercase tracking-[0.5em] font-black">Imperial Passage</span>
                <span className="text-brand-green font-black uppercase tracking-[0.3em]">Complimentary</span>
              </div>
              <div className="pt-12 border-t border-brand-gold/10 flex justify-between items-center">
                <span className="font-serif text-3xl italic text-brand-dark">Final Aura</span>
                <span className="text-4xl font-black text-brand-gold tracking-tighter">{formatPrice(cartTotal)}</span>
              </div>
            </div>

            <div className="p-10 bg-brand-gold/5 rounded-[3rem] border border-white/20 text-center relative overflow-hidden group">
              <motion.div 
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 10, repeat: Infinity }}
                className="absolute inset-0 bg-brand-gold/5 opacity-30 blur-3xl" 
              />
              <p className="text-[10px] text-brand-dark/50 italic leading-[1.8] font-serif relative z-10 px-4">
                "By committing this ethereal exchange, you acknowledge the handcrafted divine nature of Aura artifacts. Expect 7-10 cycles for celestial arrival."
              </p>
            </div>
            
            <div className="mt-12 flex justify-center items-center gap-4 text-brand-gold/40">
              <CheckCircle2 size={16} />
              <span className="text-[10px] uppercase font-black tracking-[0.4em]">Matrix Secured Connection</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

