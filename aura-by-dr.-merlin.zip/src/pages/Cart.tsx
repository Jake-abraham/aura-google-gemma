import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShoppingBag, 
  Trash2, 
  Plus, 
  Minus, 
  ArrowRight, 
  ChevronLeft,
  Tag
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useShop } from '../context/ShopContext';

export default function Cart() {
  const { cart, removeFromCart, updateQuantity, cartTotal, formatPrice } = useShop();
  const navigate = useNavigate();

  if (cart.length === 0) {
    return (
      <div className="pt-40 pb-20 px-6 min-h-screen flex flex-col items-center justify-center text-center bg-mesh">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md"
        >
          <div className="w-24 h-24 bg-white/10 backdrop-blur-3xl rounded-full flex items-center justify-center mx-auto mb-8 text-brand-gold/30 futuristic-glow">
            <ShoppingBag size={48} />
          </div>
          <h2 className="text-5xl font-serif mb-6 italic text-brand-dark">Your bag is empty</h2>
          <p className="text-brand-dark/50 mb-10 leading-relaxed italic text-lg font-serif">
            It looks like you haven't added any ethereal creations yet. Start exploring our latest collections to find your perfect fit.
          </p>
          <button 
            onClick={() => navigate('/collections')}
            className="gold-shimmer text-white px-16 py-6 rounded-full text-[10px] uppercase tracking-[0.4em] font-black shadow-2xl futuristic-glow"
          >
            Explore Collections
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="pt-40 pb-20 px-6 max-w-7xl mx-auto min-h-screen bg-mesh">
      <header className="mb-20 flex flex-col md:flex-row md:items-end justify-between gap-8">
        <div>
          <button 
            onClick={() => navigate(-1)}
            className="flex items-center gap-4 text-brand-gold text-[10px] uppercase tracking-[0.6em] font-black mb-6 hover:gap-6 transition-all"
          >
            <ChevronLeft size={14} /> Back to Studio
          </button>
          <h1 className="text-6xl font-serif italic text-brand-dark leading-tight">Shopping Bag</h1>
        </div>
        <p className="text-[10px] text-brand-dark/40 uppercase tracking-[0.4em] font-black italic border-b border-brand-gold/20 pb-2">
          {cart.reduce((acc, item) => acc + item.quantity, 0)} Items Curated
        </p>
      </header>

      <div className="flex flex-col lg:flex-row gap-20">
        {/* Cart Items */}
        <div className="flex-1 space-y-12">
          <AnimatePresence mode="popLayout">
            {cart.map((item) => (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                className="bg-white/5 backdrop-blur-3xl p-10 rounded-[4rem] shadow-2xl border border-white/20 flex flex-col sm:flex-row gap-10 group futuristic-glow"
              >
                <div className="w-full sm:w-40 aspect-[3/4] rounded-[2.5rem] overflow-hidden shadow-2xl flex-shrink-0 relative border border-white/10">
                  <img 
                    src={item.image} 
                    alt={item.name} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[1.5s]" 
                  />
                </div>

                <div className="flex-1 flex flex-col justify-between py-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-[10px] uppercase font-black tracking-[0.4em] text-brand-gold mb-3 block">
                        {item.category}
                      </span>
                      <h3 className="text-4xl font-serif text-brand-dark italic group-hover:text-brand-gold transition-colors">{item.name}</h3>
                    </div>
                    <button 
                      onClick={() => removeFromCart(item.id)}
                      className="p-5 bg-brand-rose/5 text-brand-rose rounded-full hover:bg-brand-rose hover:text-white transition-all shadow-xl group border border-brand-rose/10"
                    >
                      <Trash2 size={20} className="group-hover:rotate-12 transition-transform" />
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-10 mt-12">
                    <div className="flex items-center gap-8 bg-white/10 backdrop-blur-2xl px-8 py-4 rounded-full border border-white/20 shadow-xl">
                      <button 
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="text-brand-dark hover:text-brand-gold transition-colors"
                      >
                        <Minus size={18} />
                      </button>
                      <span className="text-lg font-black min-w-[2ch] text-center tracking-tighter">{item.quantity}</span>
                      <button 
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="text-brand-dark hover:text-brand-gold transition-colors"
                      >
                        <Plus size={18} />
                      </button>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-brand-dark/20 line-through mb-2 font-black tracking-widest">{formatPrice(item.price * 1.5, item)}</p>
                      <p className="text-3xl font-black text-brand-dark tracking-tighter">{formatPrice(item.price, item)}</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Order Summary */}
        <div className="lg:w-[450px]">
          <div className="bg-white/10 backdrop-blur-3xl p-16 rounded-[5rem] shadow-[0_50px_100px_rgba(0,0,0,0.15)] border border-white/20 sticky top-40 futuristic-glow">
            <h4 className="text-3xl font-serif mb-12 italic text-brand-dark border-b border-brand-gold/10 pb-6 text-center">Aura Manifest</h4>
            
            <div className="space-y-8 mb-16">
              <div className="flex justify-between items-center text-[10px]">
                <span className="text-brand-dark/40 uppercase tracking-[0.4em] font-black">Ethereal Volume</span>
                <span className="font-black text-brand-dark tracking-widest">{formatPrice(cartTotal)}</span>
              </div>
              <div className="flex justify-between items-center text-[10px]">
                <span className="text-brand-dark/40 uppercase tracking-[0.4em] font-black">Celestial Passage</span>
                <span className="text-brand-green font-black uppercase tracking-[0.2em]">Complimentary</span>
              </div>
              <div className="pt-10 border-t border-white/10 flex justify-between items-center">
                <span className="font-serif text-3xl italic text-brand-dark">Final Aura</span>
                <span className="text-4xl font-black text-brand-gold tracking-tighter">{formatPrice(cartTotal)}</span>
              </div>
            </div>

            <div className="mb-12 group/coupon">
              <div className="relative">
                <Tag className="absolute left-8 top-1/2 -translate-y-1/2 text-brand-gold group-focus-within/coupon:rotate-45 transition-transform" size={18} />
                <input 
                  type="text" 
                  placeholder="Cipher Code" 
                  className="w-full pl-16 pr-8 py-6 rounded-[2rem] bg-white/5 border border-white/10 focus:border-brand-gold/40 focus:outline-none text-[10px] uppercase font-black tracking-[0.4em] transition-all text-brand-dark placeholder:text-brand-dark/20 italic"
                />
              </div>
            </div>

            <motion.button 
              whileHover={{ scale: 1.02, boxShadow: '0 30px 60px rgba(200,155,60,0.3)' }}
              whileTap={{ scale: 0.98 }}
              onClick={() => navigate('/checkout')}
              className="w-full gold-shimmer text-white py-8 rounded-full text-[12px] uppercase tracking-[0.5em] font-black shadow-2xl flex items-center justify-center gap-4 group"
            >
              <span>Commit Exchange</span> <ArrowRight size={20} className="group-hover:translate-x-3 transition-transform" />
            </motion.button>
            
            <p className="mt-12 text-center text-[8px] text-brand-dark/30 uppercase tracking-[0.3em] font-black leading-relaxed">
              Programmable gift architecture <br /> available on all celestial orders
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

