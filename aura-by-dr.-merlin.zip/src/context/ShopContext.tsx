import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, Currency, CURRENCIES } from '../constants';

interface CartItem extends Product {
  quantity: number;
}

interface ShopContextType {
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartTotal: number;
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  formatPrice: (price: number, product?: Product) => string;
}

const ShopContext = createContext<ShopContextType | undefined>(undefined);

export const ShopProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('aura_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [currency, setCurrency] = useState<Currency>(() => {
    const saved = localStorage.getItem('aura_currency');
    return (saved as Currency) || 'INR';
  });

  useEffect(() => {
    localStorage.setItem('aura_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('aura_currency', currency);
  }, [currency]);

  // Mock location detection
  useEffect(() => {
    if (!localStorage.getItem('aura_currency')) {
      // In a real app, you'd call an IP geo API here
      // For now, let's default to INR but hint at how detection works
      setCurrency('INR');
    }
  }, []);

  const addToCart = (product: Product, quantity: number = 1) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [...prev, { ...product, quantity }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev => prev.map(item => 
      item.id === productId ? { ...item, quantity } : item
    ));
  };

  const clearCart = () => setCart([]);

  const getResolvedPrice = (product: Product) => {
    if (currency === 'INR' && product.priceINR) return product.priceINR;
    if (currency === 'AED' && product.priceAED) return product.priceAED;
    return product.price * CURRENCIES[currency].rate;
  };

  const formatPrice = (price: number, product?: Product) => {
    const config = CURRENCIES[currency];
    
    let resolvedPrice = price;
    if (product) {
      resolvedPrice = getResolvedPrice(product);
    } else {
      // If no product is provided, we assume the price passed is already in some base currency
      // and we just apply the exchange rate
      resolvedPrice = price * config.rate;
    }

    // Smart rounding for aesthetic
    if (currency === 'INR') resolvedPrice = Math.round(resolvedPrice);
    else if (currency === 'AED') resolvedPrice = Math.round(resolvedPrice);
    else resolvedPrice = Number(resolvedPrice.toFixed(2));

    return `${config.symbol}${resolvedPrice.toLocaleString()}`;
  };

  const cartTotal = cart.reduce((acc, item) => {
    return acc + (getResolvedPrice(item) * item.quantity);
  }, 0);

  return (
    <ShopContext.Provider value={{ 
      cart, 
      addToCart, 
      removeFromCart, 
      updateQuantity, 
      clearCart,
      cartTotal,
      currency,
      setCurrency,
      formatPrice
    }}>
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) throw new Error('useShop must be used within a ShopProvider');
  return context;
};
