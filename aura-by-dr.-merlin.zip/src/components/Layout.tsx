import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShoppingBag, 
  Menu, 
  X, 
  Search,
  Instagram,
  Facebook,
  Twitter,
  User as UserIcon,
  Globe,
  ChevronDown
} from 'lucide-react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { auth } from '../lib/firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { useShop } from '../context/ShopContext';
import { CURRENCIES, Currency } from '../constants';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCurrencyOpen, setIsCurrencyOpen] = useState(false);
  const [user, setUser] = useState(auth.currentUser);
  const navigate = useNavigate();
  const location = useLocation();
  const { cart, currency, setCurrency } = useShop();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    const unsubscribe = onAuthStateChanged(auth, (u) => setUser(u));
    return () => {
      window.removeEventListener('scroll', handleScroll);
      unsubscribe();
    };
  }, []);

  const handleSignOut = async () => {
    await signOut(auth);
    navigate('/');
  };

  const isAdminPath = location.pathname.startsWith('/admin') || location.pathname === '/admin-login';

  if (isAdminPath) return null;

  return (
    <nav 
      className={`fixed top-0 left-0 w-full z-[100] transition-all duration-1000 ease-in-out ${
        isScrolled ? 'bg-brand-cream/40 backdrop-blur-3xl py-4 shadow-[0_20px_50px_rgba(0,0,0,0.1)] border-b border-white/10' : 'bg-transparent py-10'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center group">
        <div className="hidden md:flex items-center gap-12 text-[10px] uppercase tracking-[0.5em] font-black">
          {['Home', 'Collections', 'Contact'].map((item) => (
            <Link 
              key={item}
              to={item === 'Home' ? '/' : `/${item.toLowerCase()}`} 
              className="relative py-2 group/link overflow-hidden"
            >
              <span className="relative z-10 transition-colors group-hover/link:text-brand-gold">{item}</span>
              <motion.div 
                className="absolute bottom-0 left-0 w-full h-[2px] bg-brand-gold origin-left"
                initial={{ scaleX: 0 }}
                whileHover={{ scaleX: 1 }}
                transition={{ type: 'spring', stiffness: 200, damping: 20 }}
              />
            </Link>
          ))}
          <div className="relative group/curr ml-4">
            <button 
              onClick={() => setIsCurrencyOpen(!isCurrencyOpen)}
              className="px-6 py-2 rounded-full border border-brand-gold/10 bg-white/5 backdrop-blur-xl flex items-center gap-3 hover:border-brand-gold transition-all futuristic-glow"
              onBlur={() => setTimeout(() => setIsCurrencyOpen(false), 200)}
            >
              <Globe size={14} className="text-brand-gold animate-spin-slow" /> 
              <span className="text-brand-dark">{currency}</span> 
              <ChevronDown size={10} className="opacity-40" />
            </button>
            <AnimatePresence>
              {isCurrencyOpen && (
                <motion.div 
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  className="absolute top-full left-0 mt-4 bg-white/90 backdrop-blur-3xl rounded-3xl shadow-[0_32px_64px_rgba(0,0,0,0.15)] border border-brand-gold/10 p-3 min-w-[160px] overflow-hidden"
                >
                  {(Object.keys(CURRENCIES) as Currency[]).map((c) => (
                    <button
                      key={c}
                      onClick={() => {
                        setCurrency(c);
                        setIsCurrencyOpen(false);
                      }}
                      className={`w-full text-left px-5 py-4 rounded-2xl transition-all flex items-center justify-between group/opt ${
                        currency === c ? 'bg-brand-gold text-white shadow-lg' : 'hover:bg-brand-gold/5 text-brand-dark/60 hover:text-brand-dark'
                      }`}
                    >
                      <span className="text-[10px] font-black tracking-widest uppercase">{c}</span>
                      <span className="text-[10px] opacity-40 group-hover/opt:opacity-100">{CURRENCIES[c].symbol}</span>
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        <Link to="/" className="flex flex-col items-center group">
          <div className="flex items-center gap-2">
            <h1 className="text-2xl md:text-3xl font-serif tracking-widest text-brand-dark uppercase group-hover:text-brand-gold transition-colors">
              Aura
            </h1>
            <div className="w-2 h-2 rounded-full bg-brand-gold animate-pulse" />
          </div>
          <span className="text-[10px] uppercase tracking-[0.5em] text-brand-gold/60 group-hover:text-brand-gold transition-colors -mt-1">
            By Dr. Merlin
          </span>
        </Link>

        <div className="flex items-center gap-6">
          <button className="hover:text-brand-gold transition-colors">
            <Search size={20} strokeWidth={1.5} />
          </button>
          
          {user ? (
            <div className="group relative">
              <Link to="/account" className="hover:text-brand-gold transition-colors">
                <UserIcon size={20} strokeWidth={1.5} />
              </Link>
              <div className="absolute top-full right-0 mt-2 w-48 bg-white shadow-xl rounded-xl py-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                <Link to="/account" className="block px-4 py-2 text-xs uppercase tracking-widest hover:bg-brand-cream">My Profile</Link>
                {user.email === 'jakekalloor@gmail.com' && (
                  <Link to="/admin" className="block px-4 py-2 text-xs uppercase tracking-widest hover:bg-brand-cream">Admin Panel</Link>
                )}
                <button onClick={handleSignOut} className="w-full text-left px-4 py-2 text-xs uppercase tracking-widest hover:bg-brand-cream text-brand-rose">Logout</button>
              </div>
            </div>
          ) : (
            <Link to="/auth" className="hover:text-brand-gold transition-colors">
              <UserIcon size={20} strokeWidth={1.5} />
            </Link>
          )}

          <Link to="/cart" className="hover:text-brand-gold transition-colors relative">
            <ShoppingBag size={20} strokeWidth={1.5} />
            {cart.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-brand-rose text-white text-[8px] w-4 h-4 flex items-center justify-center rounded-full ring-2 ring-brand-cream/80 animate-pulse">
                {cart.length}
              </span>
            )}
          </Link>
          
          <button 
            className="md:hidden"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-brand-cream border-t border-brand-gold/10 overflow-hidden"
          >
            <div className="flex flex-col p-8 gap-6 text-sm uppercase tracking-widest text-center">
              <Link to="/" onClick={() => setIsMobileMenuOpen(false)}>Home</Link>
              <Link to="/contact" onClick={() => setIsMobileMenuOpen(false)}>Contact</Link>
              {user ? (
                <Link to="/account" onClick={() => setIsMobileMenuOpen(false)}>My Account</Link>
              ) : (
                <Link to="/auth" onClick={() => setIsMobileMenuOpen(false)}>Login</Link>
              )}
              <div className="flex justify-center gap-4 pt-4 border-t border-brand-gold/10">
                {(Object.keys(CURRENCIES) as Currency[]).map((c) => (
                  <button 
                    key={c}
                    onClick={() => setCurrency(c)}
                    className={`px-4 py-2 rounded-full text-[10px] font-bold tracking-widest ${
                      currency === c ? 'bg-brand-gold text-white' : 'bg-white/50'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export const Footer = () => {
  return (
    <footer className="bg-brand-dark text-white pt-24 pb-12 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 border-b border-white/10 pb-16 mb-12">
          <div className="space-y-6">
            <h3 className="text-2xl font-serif tracking-widest uppercase">Aura</h3>
            <p className="text-white/60 text-sm leading-loose max-w-xs">
              Defining modern Indian bridesmaid and bridal wear with a focus on serenity, quality, and timeless grace.
            </p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-brand-gold transition-colors"><Instagram size={20} /></a>
              <a href="#" className="hover:text-brand-gold transition-colors"><Facebook size={20} /></a>
              <a href="#" className="hover:text-brand-gold transition-colors"><Twitter size={20} /></a>
            </div>
          </div>
          
          <div>
            <h4 className="text-xs uppercase tracking-widest text-brand-gold mb-8 font-bold">Shop</h4>
            <ul className="space-y-4 text-sm text-white/70">
              <li><a href="#" className="hover:text-white transition-colors">Sarees</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Kurtas</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Festive Wear</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Bridal Collection</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs uppercase tracking-widest text-brand-gold mb-8 font-bold">Client Care</h4>
            <ul className="space-y-4 text-sm text-white/70">
              <li><a href="#" className="hover:text-white transition-colors">Shipping Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Returns & Exchanges</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs uppercase tracking-widest text-brand-gold mb-8 font-bold">Visit Us</h4>
            <div className="text-white/70 text-sm space-y-4 leading-loose">
              <p>Studio 42, Heritage Block<br />South Delhi, India 110017</p>
              <p>Mon - Sat: 11:00 AM - 08:00 PM</p>
              <p>hello@aurabymerlin.com</p>
              <p className="font-bold">+91 98765 43210</p>
            </div>
          </div>
        </div>
        
        <div className="text-center text-white/40 text-[10px] uppercase tracking-widest">
          © 2024 Aura By Dr. Merlin. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

const CustomCursor = () => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isHovering, setIsHovering] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };

    const handleMouseOver = (e: any) => {
      if (e.target.closest('button, a, .group')) {
        setIsHovering(true);
      } else {
        setIsHovering(false);
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseover', handleMouseOver);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseover', handleMouseOver);
    };
  }, []);

  return (
    <motion.div
      className="fixed top-0 left-0 w-8 h-8 rounded-full border border-brand-gold pointer-events-none z-[9999] hidden lg:block mix-blend-difference"
      animate={{
        x: mousePos.x - 16,
        y: mousePos.y - 16,
        scale: isHovering ? 2 : 1,
      }}
      transition={{ type: 'spring', damping: 25, stiffness: 250, mass: 0.5 }}
    >
      <div className="absolute inset-0 bg-brand-gold/10 rounded-full blur-sm" />
    </motion.div>
  );
};

export const Layout = ({ children }: { children: React.ReactNode }) => {
  return (
    <div className="min-h-screen flex flex-col">
      <CustomCursor />
      <Navbar />
      <main className="flex-1">
        {children}
      </main>
      <Footer />
    </div>
  );
};
