import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, X, Send, User, Bot, Loader2, Sparkles, ShoppingBag, Truck, HeadphonesIcon } from 'lucide-react';
import { getChatResponse } from '../services/geminiService';
import { useNavigate } from 'react-router-dom';

export const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'model', text: string }[]>([
    { role: 'model', text: 'Namaste! I am Aura, your Ethereal Concierge. How may I guide your journey through our tradition today?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async (customText?: string) => {
    const userMessage = customText || input.trim();
    if (!userMessage || isLoading) return;

    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);

    try {
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));
      const response = await getChatResponse(userMessage, history);
      setMessages(prev => [...prev, { role: 'model', text: response }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: "Forgive me, the stars have misaligned. Please contact our human concierge at hello@aurabymerlin.com." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickActions = [
    { label: 'Find a Saree', icon: ShoppingBag, action: () => handleSend("I'm looking for a premium saree for a wedding.") },
    { label: 'Track Order', icon: Truck, action: () => navigate('/account') },
    { label: 'Talk to Stylist', icon: HeadphonesIcon, action: () => navigate('/contact') },
  ];

  return (
    <>
      <motion.button 
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-8 right-8 z-[100] w-16 h-16 gold-shimmer text-white rounded-full flex items-center justify-center shadow-[0_20px_50px_rgba(200,155,60,0.3)] border-2 border-white/20"
      >
        {isOpen ? <X size={24} /> : <div className="relative"><MessageCircle size={24} /><motion.div animate={{ scale: [1, 1.5, 1], opacity: [0, 1, 0] }} transition={{ repeat: Infinity, duration: 2 }} className="absolute -top-1 -right-1 w-3 h-3 bg-brand-rose rounded-full" /></div>}
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 40, filter: 'blur(10px)' }}
            animate={{ opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }}
            exit={{ opacity: 0, scale: 0.9, y: 40, filter: 'blur(10px)' }}
            className="fixed bottom-28 right-8 z-[100] w-[350px] md:w-[450px] h-[600px] bg-white/95 backdrop-blur-xl rounded-[3rem] shadow-[0_50px_100px_-20px_rgba(200,155,60,0.25)] overflow-hidden flex flex-col border border-brand-gold/20"
          >
            {/* Header */}
            <div className="bg-brand-dark p-8 pb-10 text-white relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-full opacity-10 floral-bg rotate-12" />
              <div className="relative z-10 flex items-center gap-4">
                <div className="w-12 h-12 bg-brand-gold rounded-2xl flex items-center justify-center shadow-lg transform -rotate-12 group">
                  <Sparkles size={24} className="text-white group-hover:rotate-12 transition-transform" />
                </div>
                <div>
                  <h3 className="font-serif text-2xl italic leading-none">Aura AI</h3>
                  <div className="flex items-center gap-2 mt-2">
                    <div className="w-2 h-2 bg-brand-green rounded-full animate-pulse" />
                    <p className="text-[10px] uppercase tracking-[0.2em] font-bold text-brand-gold">Ethereal Intelligence</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div 
              ref={scrollRef}
              className="flex-1 overflow-y-auto p-8 space-y-6 bg-brand-cream/10 custom-scrollbar"
            >
              {messages.map((m, i) => (
                <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`flex gap-4 max-w-[85%] ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
                    <div className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-md ${m.role === 'user' ? 'bg-brand-dark text-white' : 'bg-brand-gold text-white'}`}>
                      {m.role === 'user' ? <User size={18} /> : <Bot size={18} />}
                    </div>
                    <div className={`p-5 rounded-[2rem] text-sm leading-relaxed ${m.role === 'user' ? 'bg-brand-dark text-white rounded-tr-none shadow-xl' : 'bg-white text-brand-dark rounded-tl-none shadow-sm border border-brand-gold/5'}`}>
                      {m.text}
                    </div>
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-white p-5 rounded-[2rem] rounded-tl-none text-brand-gold shadow-sm border border-brand-gold/10">
                    <Loader2 className="animate-spin" size={24} />
                  </div>
                </div>
              )}
            </div>

            {/* Quick Actions */}
            {messages.length === 1 && (
              <div className="px-8 py-4 flex gap-3 overflow-x-auto scrollbar-hide">
                {quickActions.map((action, i) => (
                  <button 
                    key={i}
                    onClick={action.action}
                    className="flex-shrink-0 flex items-center gap-2 px-6 py-3 rounded-full bg-brand-gold/5 border border-brand-gold/10 text-brand- gold hover:bg-brand-gold hover:text-white transition-all text-[10px] uppercase font-black tracking-widest"
                  >
                    <action.icon size={12} />
                    {action.label}
                  </button>
                ))}
              </div>
            )}

            {/* Input Area */}
            <div className="p-8 bg-white border-t border-brand-gold/10 relative">
              <div className="flex gap-4">
                <input 
                  type="text" 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Inquire with Aura..."
                  className="flex-1 px-8 py-5 rounded-full bg-brand-cream/30 text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold/50 transition-all border border-transparent focus:bg-white placeholder:italic"
                />
                <button 
                  onClick={() => handleSend()}
                  className="w-14 h-14 bg-brand-gold text-white rounded-full flex items-center justify-center hover:bg-brand-dark transition-all shadow-xl hover:scale-105 active:scale-95"
                >
                  <Send size={20} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
