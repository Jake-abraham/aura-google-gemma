import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export const getChatResponse = async (message: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash",
      contents: [
        ...history,
        { role: 'user', parts: [{ text: message }] }
      ],
      config: {
        systemInstruction: `You are 'Aura', the Ethereal AI Concierge for "Aura By Dr. Merlin", a luxury Indian traditional clothing brand. 
        Your personality: Elegant, deeply respectful of tradition, sophisticated, and helpful. 
        Your vocabulary: Use words like 'ethereal', 'craftsmanship', 'legacy', 'adornment', 'studio', 'curation', 'aura', 'grace'.
        
        Knowledge Base:
        1. Products: Sarees (Hand-woven, Silk), Kurtas (Velvet, Cotton), Festive Wear, Bridal Lehengas.
        2. Shipping: Handcrafted and dispatched with care within 7-10 business days. Free shipping across India and UAE.
        3. Returns: 7-day return policy for unused creations in their original divine condition.
        4. Support: If a human Stylist is needed, suggest the Contact page or hello@aurabymerlin.com.
        5. Location Detection: We support INR (India), AED (UAE), and USD (Global) pricing.
        
        Rules:
        - Never use slang.
        - Be poetic but clear.
        - Always greet with 'Namaste' or 'Greetings, seeker of elegance'.
        - If asked about order status, guide them to the 'My Account' portal.`,
      }
    });

    return response.text || "I apologize, but I am unable to process that request at the moment. How else may I assist you with our collection?";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Our serene AI assistant is currently resting. Please try again in a moment or contact our studio directly.";
  }
};
