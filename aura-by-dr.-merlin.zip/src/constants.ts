export interface Product {
  id: string;
  name: string;
  category: 'Sarees' | 'Kurtas' | 'Festive Wear' | 'Bridal';
  price: number; // Base price (USD)
  priceINR?: number;
  priceAED?: number;
  image: string;
  image2?: string;
  description: string;
  isAvailable: boolean;
}

export type Currency = 'INR' | 'AED' | 'USD';

export interface CurrencyConfig {
  code: Currency;
  symbol: string;
  rate: number;
}

export const CURRENCIES: Record<Currency, CurrencyConfig> = {
  INR: { code: 'INR', symbol: '₹', rate: 83 },
  AED: { code: 'AED', symbol: 'د.إ', rate: 3.67 },
  USD: { code: 'USD', symbol: '$', rate: 1 }
};

export interface Collection {
  id: string;
  name: string;
  image: string;
  description: string;
}

export const COLLECTIONS: Collection[] = [
  {
    id: 'sarees',
    name: 'Sarees',
    image: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=800',
    description: 'Timeless elegance draped in silk and grace.'
  },
  {
    id: 'kurtas',
    name: 'Kurtas',
    image: 'https://images.unsplash.com/photo-1605333396915-47ed6b68a00e?auto=format&fit=crop&q=80&w=800',
    description: 'Contemporary silhouettes with traditional souls.'
  },
  {
    id: 'festive',
    name: 'Festive Wear',
    image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&q=80&w=800',
    description: 'Celebrate your moments in vibrant threads.'
  },
  {
    id: 'bridal',
    name: 'Bridal',
    image: 'https://images.unsplash.com/photo-1594465919760-441fe5908ab0?auto=format&fit=crop&q=80&w=800',
    description: 'The crowning glory of your most special day.'
  }
];

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Golden Bloom Silk Saree',
    category: 'Sarees',
    price: 295,
    priceINR: 24500,
    priceAED: 1085,
    image: 'https://images.unsplash.com/photo-1610189012906-40014a60ecc2?auto=format&fit=crop&q=80&w=800',
    image2: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=800',
    description: 'Hand-woven Banarasi silk saree with intricate floral gold zari work.',
    isAvailable: true
  },
  {
    id: '2',
    name: 'Rose Blush Anarkali',
    category: 'Festive Wear',
    price: 228,
    priceINR: 18900,
    priceAED: 840,
    image: 'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&q=80&w=800',
    image2: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=800',
    description: 'Floor-length georgette Anarkali with delicate hand embroidery.',
    isAvailable: true
  },
  {
    id: '3',
    name: 'Midnight Teal Kurta Set',
    category: 'Kurtas',
    price: 150,
    priceINR: 12500,
    priceAED: 550,
    image: 'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&q=80&w=800',
    image2: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=800',
    description: 'Cotton silk kurta with palazzo and embroidered dupatta.',
    isAvailable: true
  },
  {
    id: '4',
    name: 'Royal Ivory Bridal Lehenga',
    category: 'Bridal',
    price: 1025,
    priceINR: 85000,
    priceAED: 3765,
    image: 'https://images.unsplash.com/photo-1594465919760-441fe5908ab0?auto=format&fit=crop&q=80&w=800',
    image2: 'https://images.unsplash.com/photo-1607746882042-944635dfe10e?auto=format&fit=crop&q=80&w=800',
    description: 'Heavy silk lehenga with heritage zardosi and sequence work.',
    isAvailable: true
  }
];
