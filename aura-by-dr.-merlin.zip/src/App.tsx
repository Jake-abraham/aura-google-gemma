import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { motion } from 'motion/react';
import React, { useState, useEffect } from 'react';
import Home from './pages/Home';
import Auth from './pages/Auth';
import MyAccount from './pages/MyAccount';
import AdminDashboard from './pages/AdminDashboard';
import AdminLogin from './pages/AdminLogin';
import Checkout from './pages/Checkout';
import Cart from './pages/Cart';
import Contact from './pages/Contact';
import Collections from './pages/Collections';
import OrderSuccess from './pages/OrderSuccess';
import ProductPage from './pages/ProductPage';
import { Layout } from './components/Layout';
import { Chatbot } from './components/Chatbot';
import { ShopProvider } from './context/ShopContext';
import { auth, db } from './lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';

const CustomCursor = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isPointer, setIsPointer] = useState(false);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
      const target = e.target as HTMLElement;
      setIsPointer(window.getComputedStyle(target).cursor === 'pointer');
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <motion.div
      className="fixed top-0 left-0 w-8 h-8 rounded-full border border-brand-gold pointer-events-none z-[9999] hidden md:block"
      animate={{
        x: position.x - 16,
        y: position.y - 16,
        scale: isPointer ? 1.5 : 1,
        backgroundColor: isPointer ? 'rgba(200, 155, 60, 0.1)' : 'transparent',
      }}
      transition={{ type: 'spring', damping: 25, stiffness: 200, mass: 0.5 }}
    />
  );
};

const ProtectedAdminRoute = ({ children }: { children: React.ReactNode }) => {
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const d = await getDoc(doc(db, 'users', user.uid));
        setIsAdmin(d.data()?.role === 'admin' || user.email === 'jakekalloor@gmail.com');
      } else {
        setIsAdmin(false);
      }
    });
    return unsub;
  }, []);

  if (isAdmin === null) return null;
  return isAdmin ? <>{children}</> : <Navigate to="/auth" />;
};

export default function App() {
  const [flowerSeeds] = useState(() => Array.from({ length: 15 }).map(() => Math.random() * 20));

  return (
    <ShopProvider>
      <Router>
        <main className="relative bg-brand-cream selection:bg-brand-gold selection:text-white cursor-none md:overflow-x-hidden">
          <CustomCursor />
          
          <div className="fixed inset-0 floral-bg pointer-events-none z-0" />
          
          {flowerSeeds.map((seed, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: '110vh', rotate: 0 }}
              animate={{ 
                opacity: [0, 0.5, 0], 
                y: '-10vh', 
                rotate: 360,
                x: [0, 50, -50, 0]
              }}
              transition={{ 
                duration: 20, 
                delay: seed, 
                repeat: Infinity, 
                ease: "linear" 
              }}
              className="fixed pointer-events-none z-0 text-brand-gold/10"
              style={{ left: `${(i * 7) % 100}%` }}
            >
              <svg width="40" height="40" viewBox="0 0 40 40" fill="currentColor">
                <path d="M20 0C25.5 0 30 4.5 30 10C30 15.5 25.5 20 20 20C14.5 20 10 15.5 10 10C10 4.5 14.5 0 20 0ZM20 20C25.5 20 30 24.5 30 30C30 35.5 25.5 40 20 40C14.5 40 10 35.5 10 30C10 24.5 14.5 20 20 20ZM10 10C10 15.5 5.5 20 0 20C5.5 20 10 24.5 10 30M30 10C30 15.5 34.5 20 40 20C34.5 20 30 24.5 30 30" />
              </svg>
            </motion.div>
          ))}

          <Routes>
            <Route path="/" element={<Layout><Home /></Layout>} />
            <Route path="/auth" element={<Layout><Auth /></Layout>} />
            <Route path="/account" element={<Layout><MyAccount /></Layout>} />
            <Route path="/cart" element={<Layout><Cart /></Layout>} />
            <Route path="/checkout" element={<Layout><Checkout /></Layout>} />
            <Route path="/collections" element={<Layout><Collections /></Layout>} />
            <Route path="/product/:id" element={<Layout><ProductPage /></Layout>} />
            <Route path="/contact" element={<Layout><Contact /></Layout>} />
            <Route path="/order-success" element={<OrderSuccess />} />
            <Route path="/admin-login" element={<AdminLogin />} />
            <Route path="/admin/*" element={
              <ProtectedAdminRoute>
                <AdminDashboard />
              </ProtectedAdminRoute>
            } />
          </Routes>

          <Chatbot />
        </main>
      </Router>
    </ShopProvider>
  );
}
